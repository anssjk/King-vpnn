"""نقطه‌ی ورود وب‌سرور Mini App.

اجرا:
    python webapp_main.py

این فرآیند جدا از bot.py اجرا می‌شود، ولی هر دو باید به یک توکن و یک
پوشه‌ی دانلود دسترسی داشته باشند. برای ارسال فایل به چت، وب‌سرور خودش
یک Bot API سبک می‌سازد (بدون polling) و فایل را می‌فرستد.
"""

from __future__ import annotations

import asyncio
import logging
import sys

from aiohttp import web
from telegram import Bot
from telegram.constants import ParseMode
from telegram.error import TelegramError
from telegram.request import HTTPXRequest

from config import ConfigError, Settings, get_settings
from downloader import Downloader, DownloadResult
from utils.files import human_size
from webapp.server import create_app
from webapp.service import DownloadService

logger = logging.getLogger(__name__)


def setup_logging(level: str) -> None:
    logging.basicConfig(
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        level=getattr(logging, level, logging.INFO),
        stream=sys.stdout,
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)


def build_bot(settings: Settings) -> Bot:
    """یک Bot سبک برای ارسال فایل — بدون polling."""
    request = HTTPXRequest(
        connection_pool_size=4,
        connect_timeout=30.0,
        read_timeout=300.0,
        write_timeout=300.0,
    )
    kwargs = {"token": settings.bot_token, "request": request}

    if settings.local_api_url:
        base = settings.local_api_url.rstrip("/")
        kwargs["base_url"] = f"{base}/bot"
        kwargs["base_file_url"] = f"{base}/file/bot"

    return Bot(**kwargs)


def make_sender(bot: Bot, settings: Settings):
    """تابع ارسال فایل به چت — همان چیزی که سرویس انتظار دارد."""

    async def send(chat_id: int, result: DownloadResult) -> None:
        title = (result.title or "ویدیو").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        size = human_size(result.filesize)

        if result.is_audio:
            caption = f"🎵 <b>{title}</b>\n📦 {size}"
            try:
                with result.path.open("rb") as fh:
                    await bot.send_audio(
                        chat_id=chat_id,
                        audio=fh,
                        caption=caption,
                        parse_mode=ParseMode.HTML,
                        title=result.title[:64],
                        read_timeout=300,
                        write_timeout=300,
                    )
                return
            except TelegramError as exc:
                logger.warning("ارسال صدا ناموفق، تلاش به‌عنوان فایل: %s", exc)

        caption = f"🎬 <b>{title}</b>\n📦 {size}"

        try:
            with result.path.open("rb") as fh:
                await bot.send_video(
                    chat_id=chat_id,
                    video=fh,
                    caption=caption,
                    parse_mode=ParseMode.HTML,
                    supports_streaming=True,
                    width=result.width,
                    height=result.height,
                    duration=result.duration,
                    read_timeout=300,
                    write_timeout=300,
                )
            return
        except TelegramError as exc:
            logger.warning("ارسال ویدیو ناموفق، تلاش به‌عنوان فایل: %s", exc)

        with result.path.open("rb") as fh:
            await bot.send_document(
                chat_id=chat_id,
                document=fh,
                caption=caption,
                parse_mode=ParseMode.HTML,
                read_timeout=300,
                write_timeout=300,
            )

    return send


async def run(settings: Settings) -> None:
    settings.download_dir.mkdir(parents=True, exist_ok=True)

    bot = build_bot(settings)
    downloader = Downloader(settings)
    service = DownloadService(settings, downloader, sender=make_sender(bot, settings))

    app = create_app(settings, service)
    runner = web.AppRunner(app)
    await runner.setup()

    site = web.TCPSite(runner, settings.web_host, settings.web_port)
    await site.start()

    logger.info(
        "Mini App روی http://%s:%d آماده است (سقف ارسال: %s)",
        settings.web_host,
        settings.web_port,
        human_size(settings.upload_limit),
    )

    try:
        await asyncio.Event().wait()  # تا ابد
    finally:
        await runner.cleanup()
        await bot.shutdown()


def main() -> int:
    try:
        settings = get_settings()
    except ConfigError as exc:
        print(f"❌ خطای تنظیمات:\n{exc}", file=sys.stderr)
        return 1

    setup_logging(settings.log_level)

    try:
        asyncio.run(run(settings))
    except KeyboardInterrupt:
        logger.info("خاموش شد.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
