"""رجیستری کارهای در جریان.

چرا لازم است؟
دکمه‌های اینلاین فقط یک رشته‌ی کوتاه (callback_data) حمل می‌کنند. وقتی
کاربر «۷۲۰p» را می‌زند، هندلر باید بداند این دکمه به کدام لینک و کدام
اطلاعات ویدیو تعلق دارد. این کلاس همان نگاشت را نگه می‌دارد.

همچنین پرچم لغو (cancel) اینجاست: دکمه‌ی «لغو» فقط یک رویداد را ست
می‌کند و حلقه‌ی دانلود آن را می‌بیند و متوقف می‌شود.
"""

from __future__ import annotations

import secrets
import threading
import time
from dataclasses import dataclass, field
from typing import Any

# کارها بعد از این مدت منقضی می‌شوند (ثانیه) — جلوگیری از رشد حافظه
JOB_TTL = 30 * 60


@dataclass
class Job:
    job_id: str
    url: str
    platform: str
    title: str
    duration: int | None
    heights: list[int]
    info: dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    # --- کنترل اجرا ---
    cancel_event: threading.Event = field(default_factory=threading.Event)
    running: bool = False

    @property
    def cancelled(self) -> bool:
        return self.cancel_event.is_set()

    def cancel(self) -> None:
        self.cancel_event.set()

    @property
    def expired(self) -> bool:
        return (time.time() - self.created_at) > JOB_TTL


class JobRegistry:
    """نگه‌دارنده‌ی کارها با قفل — چند کاربر همزمان امن است."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._jobs: dict[str, Job] = {}

    # ------------------------------------------------------------------
    def create(
        self,
        *,
        url: str,
        platform: str,
        title: str,
        duration: int | None,
        heights: list[int],
        info: dict[str, Any] | None = None,
    ) -> Job:
        job_id = secrets.token_hex(4)  # ۸ کاراکتر — داخل ۶۴ بایت جا می‌شود
        job = Job(
            job_id=job_id,
            url=url,
            platform=platform,
            title=title,
            duration=duration,
            heights=heights,
            info=info or {},
        )
        with self._lock:
            self._purge_locked()
            self._jobs[job_id] = job
        return job

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return None
            if job.expired:
                self._jobs.pop(job_id, None)
                return None
            return job

    def drop(self, job_id: str) -> None:
        with self._lock:
            self._jobs.pop(job_id, None)

    def active_count(self) -> int:
        with self._lock:
            return sum(1 for j in self._jobs.values() if j.running)

    def _purge_locked(self) -> None:
        stale = [k for k, j in self._jobs.items() if j.expired]
        for key in stale:
            self._jobs.pop(key, None)


# نمونه‌ی سراسری — در bot_data هم گذاشته می‌شود تا تست‌پذیر بماند
registry = JobRegistry()
