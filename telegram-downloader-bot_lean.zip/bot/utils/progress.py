"""انتقال امن پیشرفت دانلود از ترد yt-dlp به حلقه‌ی asyncio."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field


@dataclass
class ProgressState:
    status: str = "starting"  # starting | downloading | finished | error
    downloaded: int = 0
    total: int = 0
    speed: float = 0.0
    eta: int = 0

    @property
    def percent(self) -> float:
        if self.total <= 0:
            return 0.0
        return min(100.0, self.downloaded * 100.0 / self.total)


class ProgressTracker:
    """yt-dlp در یک ترد جدا اجرا می‌شود؛ این کلاس وضعیت را
    با قفل به حلقه‌ی اصلی منتقل می‌کند تا race condition نباشد.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state = ProgressState()

    def update(self, **fields: object) -> None:
        with self._lock:
            for key, value in fields.items():
                if hasattr(self._state, key):
                    setattr(self._state, key, value)

    def snapshot(self) -> ProgressState:
        with self._lock:
            return ProgressState(
                status=self._state.status,
                downloaded=self._state.downloaded,
                total=self._state.total,
                speed=self._state.speed,
                eta=self._state.eta,
            )

    # --- سازگار با progress_hooks یت‌دی‌ال‌پی ---
    def hook(self, data: dict) -> None:
        status = data.get("status")
        if status == "downloading":
            self.update(
                status="downloading",
                downloaded=int(data.get("downloaded_bytes") or 0),
                total=int(data.get("total_bytes") or data.get("total_bytes_estimate") or 0),
                speed=float(data.get("speed") or 0.0),
                eta=int(data.get("eta") or 0),
            )
        elif status == "finished":
            self.update(status="finished")
