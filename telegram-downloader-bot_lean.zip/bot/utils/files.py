"""کار با فایل: نمایش حجم، پاک‌سازی، فرمت زمان."""

from __future__ import annotations

import logging
import shutil
import time
from pathlib import Path

logger = logging.getLogger(__name__)


def human_size(num_bytes: int) -> str:
    """۱۲۳۴۵۶۷ → «1.2 MB»"""
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def human_duration(seconds: int | None) -> str:
    """۳۷۵۰ → «1:02:30»"""
    if not seconds or seconds <= 0:
        return "نامشخص"
    seconds = int(seconds)
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def progress_bar(percent: float, width: int = 12) -> str:
    """نوار پیشرفت متنی: ██████░░░░░░ 50٪"""
    percent = max(0.0, min(100.0, percent))
    filled = int(width * percent / 100)
    bar = "█" * filled + "░" * (width - filled)
    return f"{bar} {percent:.0f}٪"


def remove_tree(path: Path) -> None:
    """حذف پوشه‌ی موقت بدون پرتاب خطا."""
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:  # pragma: no cover - فقط برای اطمینان
        logger.warning("پاک‌سازی ناموفق: %s", path, exc_info=True)


def purge_old_files(directory: Path, max_age_seconds: int = 3600) -> int:
    """حذف پوشه‌های موقت قدیمی‌تر از max_age_seconds.

    برای وقتی که ربات وسط کار کرش کرده و فایل‌ها جا مانده‌اند.
    """
    if not directory.is_dir():
        return 0

    now = time.time()
    removed = 0
    for entry in directory.iterdir():
        try:
            age = now - entry.stat().st_mtime
        except OSError:
            continue
        if age > max_age_seconds:
            if entry.is_dir():
                remove_tree(entry)
            else:
                entry.unlink(missing_ok=True)
            removed += 1

    if removed:
        logger.info("%d فایل/پوشه‌ی قدیمی پاک شد.", removed)
    return removed
