"""ساخت دکمه‌های اینلاین.

همه‌ی چیدمان دکمه‌ها اینجاست تا هندلرها فقط منطق داشته باشند.

قالب callback_data:  «عمل:پارامتر»  — مثلاً  q:ab12cd:720
محدودیت تلگرام: callback_data حداکثر ۶۴ بایت است، پس شناسه‌ی کار را
کوتاه نگه می‌داریم (۸ کاراکتر هگز).
"""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from utils import messages as msg

# ----------------------------------------------------------------------
# شناسه‌ی عمل‌ها — در هندلرها هم از همین‌ها استفاده می‌شود
# ----------------------------------------------------------------------
ACT_MENU = "menu"
ACT_HELP = "help"
ACT_PLATFORMS = "plat"
ACT_STATUS = "stat"
ACT_QUALITY = "q"
ACT_AUDIO = "a"
ACT_CANCEL = "x"
ACT_AGAIN = "again"
ACT_WEBAPP = "webapp"

# ارتفاع‌های پیشنهادی برای انتخاب کیفیت (فقط آن‌هایی که ویدیو دارد)
QUALITY_CHOICES = (360, 480, 720, 1080)


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _webapp_btn(text: str, url: str) -> InlineKeyboardButton:
    """دکمه‌ای که Mini App را باز می‌کند.

    تلگرام فقط آدرس HTTPS را می‌پذیرد؛ اگر آدرس تنظیم نشده باشد،
    این دکمه ساخته نمی‌شود.
    """
    return InlineKeyboardButton(text, web_app=WebAppInfo(url=url))


# ----------------------------------------------------------------------
# منوی اصلی
# ----------------------------------------------------------------------
def main_menu(webapp_url: str = "") -> InlineKeyboardMarkup:
    """منوی اصلی: دکمه‌ی Mini App (اگر تنظیم شده) + دو ردیف دو‌ستونی + یک ردیف تمام‌عرض.

    چیدمان دو‌ستونی همان چیزی است که حس «کارت شیشه‌ای» می‌دهد؛
    تلگرام دکمه‌های هم‌ردیف را با فاصله‌ی یکسان می‌چیند.
    """
    rows: list[list[InlineKeyboardButton]] = []

    # دکمه‌ی Mini App — برجسته‌ترین انتخاب، تمام‌عرض و اول
    if webapp_url:
        rows.append([_webapp_btn(msg.BTN_WEBAPP, webapp_url)])

    rows.extend(
        [
            [
                _btn(msg.BTN_HELP, f"{ACT_HELP}:"),
                _btn(msg.BTN_PLATFORMS, f"{ACT_PLATFORMS}:"),
            ],
            [
                _btn(msg.BTN_STATUS, f"{ACT_STATUS}:"),
                _btn(msg.BTN_CANCEL, f"{ACT_CANCEL}:"),
            ],
            [_btn(msg.BTN_MAIN, f"{ACT_MENU}:")],
        ]
    )

    return InlineKeyboardMarkup(rows)


def back_menu() -> InlineKeyboardMarkup:
    """برای صفحه‌های راهنما/پلتفرم‌ها/وضعیت."""
    return InlineKeyboardMarkup(
        [[_btn(msg.BTN_BACK, f"{ACT_MENU}:")]]
    )


# ----------------------------------------------------------------------
# انتخاب کیفیت
# ----------------------------------------------------------------------
def quality_menu(
    job_id: str,
    heights: list[int],
    *,
    has_audio: bool = True,
) -> InlineKeyboardMarkup:
    """دکمه‌های کیفیت + صدا + لغو.

    heights: ارتفاع‌های واقعاً موجود در این ویدیو (نزولی).
    اگر خالی باشد، فقط «بهترین کیفیت» و صدا نشان داده می‌شود.
    """
    rows: list[list[InlineKeyboardButton]] = []

    # ردیف اول: بهترین کیفیت (تمام‌عرض — برجسته‌ترین انتخاب)
    rows.append([_btn(msg.BTN_BEST, f"{ACT_QUALITY}:{job_id}:best")])

    # ردیف‌های بعدی: کیفیت‌های مشخص، دو‌ستونی
    picked = [h for h in QUALITY_CHOICES if h in heights]
    if not picked:
        picked = sorted(heights, reverse=True)[:4]

    pair: list[InlineKeyboardButton] = []
    for height in picked:
        pair.append(
            _btn(msg.BTN_QUALITY.format(height=height), f"{ACT_QUALITY}:{job_id}:{height}")
        )
        if len(pair) == 2:
            rows.append(pair)
            pair = []
    if pair:
        rows.append(pair)

    # صدا
    if has_audio:
        rows.append([_btn(msg.BTN_AUDIO, f"{ACT_AUDIO}:{job_id}")])

    # لغو
    rows.append([_btn(msg.BTN_CANCEL, f"{ACT_CANCEL}:{job_id}")])

    return InlineKeyboardMarkup(rows)


# ----------------------------------------------------------------------
# در حین دانلود
# ----------------------------------------------------------------------
def downloading_menu(job_id: str) -> InlineKeyboardMarkup:
    """فقط یک دکمه: لغو."""
    return InlineKeyboardMarkup(
        [[_btn(msg.BTN_CANCEL, f"{ACT_CANCEL}:{job_id}")]]
    )


# ----------------------------------------------------------------------
# بعد از پایان
# ----------------------------------------------------------------------
def after_download_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [_btn(msg.BTN_AGAIN, f"{ACT_MENU}:")],
            [_btn(msg.BTN_MAIN, f"{ACT_MENU}:")],
        ]
    )


# ----------------------------------------------------------------------
# تجزیه‌ی callback_data
# ----------------------------------------------------------------------
def parse_callback(data: str) -> tuple[str, str, str]:
    """«q:ab12cd:720» → ("q", "ab12cd", "720")

    بخش‌های غایب با رشته‌ی خالی پر می‌شوند تا هندلر لازم نباشد
    None-check کند.
    """
    parts = (data or "").split(":")
    action = parts[0] if parts else ""
    job_id = parts[1] if len(parts) > 1 else ""
    value = parts[2] if len(parts) > 2 else ""
    return action, job_id, value
