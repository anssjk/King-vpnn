"""نوع‌های خطای دامنه و نگاشت آن‌ها به پیام فارسی."""

from __future__ import annotations

from enum import Enum


class DownloadErrorKind(str, Enum):
    PRIVATE = "private"
    UNAVAILABLE = "unavailable"
    LOGIN_REQUIRED = "login_required"
    BOT_CHECK = "bot_check"
    NOT_FOUND = "not_found"
    NETWORK = "network"
    TOO_LONG = "too_long"
    TOO_LARGE = "too_large"
    UNSUPPORTED = "unsupported"
    UNKNOWN = "unknown"


class DownloadError(Exception):
    """خطای قابل‌نمایش به کاربر."""

    def __init__(self, kind: DownloadErrorKind, detail: str = "") -> None:
        super().__init__(detail or kind.value)
        self.kind = kind
        self.detail = detail


# الگوهای متن خطای yt-dlp → نوع خطا
_PATTERNS: tuple[tuple[tuple[str, ...], DownloadErrorKind], ...] = (
    (
        (
            "private video",
            "this video is private",
            "private account",
            "only available for followers",
            "requested content is not available",
        ),
        DownloadErrorKind.PRIVATE,
    ),
    (
        (
            "sign in to confirm",
            "confirm you're not a bot",
            "confirm you’re not a bot",
            "cookies-from-browser",
            "login required",
            "requires authentication",
            "rate-limit reached",
            "too many requests",
            "http error 429",
        ),
        DownloadErrorKind.BOT_CHECK,
    ),
    (
        (
            "login required",
            "you need to log in",
            "authentication required",
            "cookies",
        ),
        DownloadErrorKind.LOGIN_REQUIRED,
    ),
    (
        (
            "video unavailable",
            "video is unavailable",
            "this video is not available",
            "has been removed",
            "no longer available",
            "account has been terminated",
            "content isn't available",
            "content is not available",
            "requested format is not available",
        ),
        DownloadErrorKind.UNAVAILABLE,
    ),
    (
        (
            "404",
            "not found",
            "does not exist",
            "unsupported url",
            "no video formats found",
        ),
        DownloadErrorKind.NOT_FOUND,
    ),
    (
        (
            "timed out",
            "connection",
            "network is unreachable",
            "temporary failure",
            "ssl",
            "getaddrinfo",
            "http error 5",
        ),
        DownloadErrorKind.NETWORK,
    ),
)


def classify(message: str) -> DownloadErrorKind:
    """متن خطای خام yt-dlp را به نوع خطا تبدیل می‌کند."""
    lowered = (message or "").lower()
    for needles, kind in _PATTERNS:
        if any(needle in lowered for needle in needles):
            return kind
    return DownloadErrorKind.UNKNOWN
