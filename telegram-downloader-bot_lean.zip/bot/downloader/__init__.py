"""موتور دانلود و تشخیص لینک."""

from downloader.engine import (
    DownloadCancelled,
    Downloader,
    DownloadResult,
    available_heights,
    ffmpeg_available,
)
from downloader.errors import DownloadError, DownloadErrorKind
from downloader.links import (
    InvalidLink,
    LinkInfo,
    UnsupportedSite,
    detect_platform,
    extract_url,
    parse_link,
)

__all__ = [
    "Downloader",
    "DownloadResult",
    "DownloadCancelled",
    "DownloadError",
    "DownloadErrorKind",
    "InvalidLink",
    "LinkInfo",
    "UnsupportedSite",
    "available_heights",
    "detect_platform",
    "extract_url",
    "ffmpeg_available",
    "parse_link",
]
