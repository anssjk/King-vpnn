"""تشخیص پلتفرم از روی لینک و اعتبارسنجی آن."""

from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlparse

# دامنه‌های هر پلتفرم (بدون www.)
YOUTUBE_HOSTS = {
    "youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "youtu.be",
    "youtube-nocookie.com",
}
INSTAGRAM_HOSTS = {"instagram.com", "instagr.am", "ddinstagram.com"}
TIKTOK_HOSTS = {"tiktok.com", "vm.tiktok.com", "vt.tiktok.com"}

# الگوی لینک داخل متن (کاربر ممکن است متن + لینک بفرستد)
URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)


@dataclass(frozen=True)
class LinkInfo:
    url: str
    platform: str  # youtube | instagram | tiktok


class UnsupportedSite(ValueError):
    """دامنه در فهرست پشتیبانی نیست."""


class InvalidLink(ValueError):
    """لینک ساختار درستی ندارد."""


def extract_url(text: str) -> str | None:
    """اولین لینک http(s) را از متن بیرون می‌کشد."""
    match = URL_RE.search(text or "")
    return match.group(0).rstrip(".,;:!؟?»«)") if match else None


def _normalize_host(host: str) -> str:
    host = host.lower().strip(".")
    return host[4:] if host.startswith("www.") else host


def detect_platform(url: str) -> str:
    """نام پلتفرم را برمی‌گرداند یا UnsupportedSite می‌دهد."""
    try:
        parsed = urlparse(url)
    except ValueError as exc:
        raise InvalidLink(url) from exc

    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise InvalidLink(url)

    host = _normalize_host(parsed.hostname or "")

    if host in YOUTUBE_HOSTS:
        return "youtube"
    if host in INSTAGRAM_HOSTS:
        return "instagram"
    if host in TIKTOK_HOSTS:
        return "tiktok"

    # زیردامنه‌های شناخته‌شده (مثلاً m.tiktok.com)
    for known, name in (
        (YOUTUBE_HOSTS, "youtube"),
        (INSTAGRAM_HOSTS, "instagram"),
        (TIKTOK_HOSTS, "tiktok"),
    ):
        if any(host.endswith("." + h) for h in known):
            return name

    raise UnsupportedSite(host)


def parse_link(text: str) -> LinkInfo:
    """متن کاربر → LinkInfo. خطاها را با پیام مناسب پرتاب می‌کند."""
    url = extract_url(text)
    if not url:
        raise InvalidLink("no-url")
    return LinkInfo(url=url, platform=detect_platform(url))
