"""موتور دانلود بر پایه‌ی yt-dlp.

yt-dlp هم یوتیوب، هم اینستاگرام و هم تیک‌تاک را پشتیبانی می‌کند،
پس یک موتور برای هر سه کافی است. این ماژول هیچ چیزی از تلگرام
نمی‌داند تا جداگانه قابل تست باشد.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path

from config import Settings
from downloader.errors import DownloadError, DownloadErrorKind, classify
from utils.progress import ProgressTracker

logger = logging.getLogger(__name__)


class DownloadCancelled(Exception):
    """کاربر دکمه‌ی لغو را زد."""


def ffmpeg_available() -> bool:
    """آیا ffmpeg نصب است؟

    بدون ffmpeg نمی‌توان ویدیو و صدا را merge کرد، پس باید
    فرمت‌های «تک‌فایلی» (که صدا داخلشان است) را انتخاب کنیم.
    """
    return shutil.which("ffmpeg") is not None


@dataclass
class DownloadResult:
    path: Path
    title: str
    duration: int | None
    filesize: int
    platform: str
    width: int | None = None
    height: int | None = None
    is_audio: bool = False


# ----------------------------------------------------------------------
# استخراج ارتفاع‌های موجود از اطلاعات probe
# ----------------------------------------------------------------------
def available_heights(info: dict) -> list[int]:
    """ارتفاع‌های واقعاً موجود در این ویدیو، نزولی و بدون تکرار.

    yt-dlp در formats فهرست همه‌ی فرمت‌ها را می‌دهد؛ آن‌هایی که
    height دارند و ویدیویی هستند را برمی‌داریم.
    """
    heights: set[int] = set()

    for fmt in info.get("formats") or []:
        if not isinstance(fmt, dict):
            continue
        # فقط فرمت‌هایی که هم ویدیو دارند هم صدا یا ویدیوی خالص
        vcodec = fmt.get("vcodec")
        if vcodec in (None, "none"):
            continue
        height = fmt.get("height")
        if isinstance(height, int) and height > 0:
            heights.add(height)

    # اگر formats نبود، از خود info استفاده کن
    if not heights:
        height = info.get("height")
        if isinstance(height, int) and height > 0:
            heights.add(height)

    return sorted(heights, reverse=True)


class Downloader:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    # ------------------------------------------------------------------
    # ساخت گزینه‌های yt-dlp
    # ------------------------------------------------------------------
    def _base_opts(
        self,
        out_dir: Path,
        tracker: ProgressTracker,
        cancel_event: threading.Event | None = None,
    ) -> dict:
        opts: dict = {
            "outtmpl": str(out_dir / "%(id)s.%(ext)s"),
            "quiet": True,
            "no_warnings": True,
            "noprogress": True,
            "noplaylist": True,
            "progress_hooks": [self._make_hook(tracker, cancel_event)],
            "retries": 3,
            "fragment_retries": 3,
            "socket_timeout": 30,
            "restrictfilenames": True,
            "concurrent_fragment_downloads": 4,
            # فایل‌های بزرگ را از قبل رد نکن؛ خودمان بررسی می‌کنیم
            "max_filesize": None,
        }

        if self.settings.cookies_file:
            opts["cookiefile"] = str(self.settings.cookies_file)

        return opts

    @staticmethod
    def _make_hook(tracker: ProgressTracker, cancel_event: threading.Event | None):
        """هوک پیشرفت + بررسی لغو.

        yt-dlp اگر هوک استثنا پرتاب کند، دانلود را متوقف می‌کند.
        این تنها راه تمیز برای لغو وسط دانلود است.
        """

        def hook(data: dict) -> None:
            if cancel_event is not None and cancel_event.is_set():
                raise DownloadCancelled("cancelled by user")
            tracker.hook(data)

        return hook

    # ------------------------------------------------------------------
    # انتخاب فرمت
    # ------------------------------------------------------------------
    def _format_selector(
        self,
        height: int | None = None,
        *,
        audio_only: bool = False,
    ) -> str:
        """سلکتور فرمت بر اساس کیفیت درخواستی.

        height=None یعنی «بهترین کیفیت تا سقف تنظیمات».
        audio_only=True یعنی فقط صدا (بهترین m4a، یا هر صدای موجود).
        """
        if audio_only:
            return "bestaudio[ext=m4a]/bestaudio/best"

        h = height or self.settings.max_height

        if not ffmpeg_available():
            logger.warning(
                "ffmpeg پیدا نشد — فقط فرمت‌های تک‌فایلی دانلود می‌شوند "
                "(کیفیت ممکن است پایین‌تر باشد)."
            )
            # 18 = 360p mp4 با صدا؛ کلاسیک‌ترین فرمت تک‌فایلی یوتیوب
            return (
                f"18/best[height<={h}][ext=mp4]/"
                f"best[height<={h}]/"
                f"best[ext=mp4]/"
                f"best/worst"
            )

        return (
            f"bestvideo[height<={h}][ext=mp4]+bestaudio[ext=m4a]/"
            f"bestvideo[height<={h}]+bestaudio/"
            f"best[height<={h}][ext=mp4]/"
            f"best[height<={h}]/best"
        )

    # ------------------------------------------------------------------
    # استخراج اطلاعات بدون دانلود
    # ------------------------------------------------------------------
    def _probe(self, url: str) -> dict:
        import yt_dlp

        opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
            "socket_timeout": 30,
        }
        if self.settings.cookies_file:
            opts["cookiefile"] = str(self.settings.cookies_file)

        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)

    async def probe(self, url: str) -> dict:
        """اطلاعات ویدیو را در ترد جدا می‌گیرد (بدون بلاک‌کردن ربات)."""
        try:
            return await asyncio.to_thread(self._probe, url)
        except Exception as exc:  # noqa: BLE001 - yt-dlp خطاهای متنوعی دارد
            raise self._to_download_error(exc) from exc

    # ------------------------------------------------------------------
    # دانلود
    # ------------------------------------------------------------------
    def _download_sync(
        self,
        url: str,
        out_dir: Path,
        tracker: ProgressTracker,
        height: int | None,
        audio_only: bool,
        cancel_event: threading.Event | None,
    ) -> DownloadResult:
        import yt_dlp

        opts = self._base_opts(out_dir, tracker, cancel_event)
        opts["format"] = self._format_selector(height, audio_only=audio_only)
        if not audio_only:
            opts["merge_output_format"] = "mp4"

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
        except DownloadCancelled:
            raise
        except Exception as exc:  # noqa: BLE001
            # اگر وسط کار لغو شده، خطای yt-dlp را نادیده بگیر
            if cancel_event is not None and cancel_event.is_set():
                raise DownloadCancelled("cancelled by user") from exc
            raise

        if info is None:
            raise DownloadError(DownloadErrorKind.NOT_FOUND)

        # پلی‌لیست: اولین ورودی را بردار
        if info.get("_type") == "playlist":
            entries = [e for e in (info.get("entries") or []) if e]
            if not entries:
                raise DownloadError(DownloadErrorKind.NOT_FOUND)
            info = entries[0]

        path = self._resolve_output_path(info, out_dir, audio_only)
        if path is None:
            raise DownloadError(DownloadErrorKind.UNKNOWN, "فایل خروجی پیدا نشد")

        return DownloadResult(
            path=path,
            title=(info.get("title") or "ویدیو").strip()[:200],
            duration=info.get("duration"),
            filesize=path.stat().st_size,
            platform=(info.get("extractor_key") or "").lower(),
            width=info.get("width"),
            height=info.get("height"),
            is_audio=audio_only,
        )

    def _resolve_output_path(
        self, info: dict, out_dir: Path, audio_only: bool = False
    ) -> Path | None:
        """مسیر فایل نهایی را پیدا می‌کند.

        yt-dlp مسیر را در requested_downloads می‌گذارد، ولی بعد از
        merge ممکن است پسوند عوض شود؛ پس هر دو را بررسی می‌کنیم.
        """
        candidates: list[Path] = []

        for item in info.get("requested_downloads") or []:
            for key in ("filepath", "_filename"):
                if item.get(key):
                    candidates.append(Path(item[key]))

        for key in ("filepath", "_filename"):
            if info.get(key):
                candidates.append(Path(info[key]))

        for candidate in candidates:
            if candidate.is_file() and candidate.stat().st_size > 0:
                return candidate

        # آخرین راه: بزرگ‌ترین فایل رسانه‌ای داخل پوشه
        if audio_only:
            exts = {".m4a", ".mp3", ".opus", ".webm", ".ogg", ".aac"}
        else:
            exts = {".mp4", ".mkv", ".webm", ".mov"}

        media = [
            p for p in out_dir.iterdir() if p.is_file() and p.suffix.lower() in exts
        ]
        if media:
            return max(media, key=lambda p: p.stat().st_size)

        return None

    async def download(
        self,
        url: str,
        out_dir: Path,
        tracker: ProgressTracker,
        *,
        height: int | None = None,
        audio_only: bool = False,
        cancel_event: threading.Event | None = None,
    ) -> DownloadResult:
        """دانلود در ترد جدا تا event loop ربات قفل نشود."""
        try:
            return await asyncio.to_thread(
                self._download_sync,
                url,
                out_dir,
                tracker,
                height,
                audio_only,
                cancel_event,
            )
        except DownloadCancelled:
            raise
        except DownloadError:
            raise
        except Exception as exc:  # noqa: BLE001
            if cancel_event is not None and cancel_event.is_set():
                raise DownloadCancelled("cancelled by user") from exc
            raise self._to_download_error(exc) from exc

    # ------------------------------------------------------------------
    # نگاشت خطا
    # ------------------------------------------------------------------
    @staticmethod
    def _to_download_error(exc: Exception) -> DownloadError:
        message = str(exc)
        kind = classify(message)
        logger.warning("خطای دانلود [%s]: %s", kind.value, message[:300])
        return DownloadError(kind, message)
