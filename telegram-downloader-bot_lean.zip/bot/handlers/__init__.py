"""هندلرهای تلگرام."""

from handlers.commands import (
    cmd_help,
    cmd_start,
    on_help,
    on_menu,
    on_platforms,
    on_status,
)
from handlers.download import (
    handle_link,
    on_audio,
    on_cancel,
    on_error,
    on_quality,
)

__all__ = [
    "cmd_start",
    "cmd_help",
    "handle_link",
    "on_error",
    "on_menu",
    "on_help",
    "on_platforms",
    "on_status",
    "on_quality",
    "on_audio",
    "on_cancel",
]
