"""دستورها و منوی اصلی: /start، /help و دکمه‌های منو."""

from __future__ import annotations

import time

from telegram import Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, TelegramError
from telegram.ext import ContextTypes

from config import Settings
from utils import keyboards as kb
from utils import messages as msg
from utils.files import human_duration, human_size
from utils.jobs import JobRegistry

# زمان شروع پروسه — برای نمایش «مدت فعالیت»
STARTED_AT = time.time()


def _uptime() -> str:
    seconds = int(time.time() - STARTED_AT)
    hours, rest = divmod(seconds, 3600)
    minutes, _ = divmod(rest, 60)
    if hours:
        return f"{hours} ساعت و {minutes} دقیقه"
    return f"{minutes} دقیقه"


def _menu(settings: Settings):
    """منوی اصلی با دکمه‌ی Mini App اگر آدرس تنظیم شده باشد."""
    return kb.main_menu(settings.webapp_url)


def _welcome(settings: Settings) -> str:
    """متن خوش‌آمد بر اساس وجود Mini App."""
    return msg.WELCOME_WEBAPP if settings.has_webapp else msg.WELCOME


async def _safe_edit(message, text: str, markup=None) -> None:
    """ویرایش پیام؛ اگر تغییری نکرده یا پیام رفته، خطا ندهد."""
    try:
        await message.edit_text(
            text,
            parse_mode=ParseMode.HTML,
            reply_markup=markup,
            disable_web_page_preview=True,
        )
    except BadRequest:
        pass
    except TelegramError:
        pass


# ----------------------------------------------------------------------
# /start
# ----------------------------------------------------------------------
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings: Settings = context.application.bot_data["settings"]
    await update.effective_message.reply_text(
        _welcome(settings),
        parse_mode=ParseMode.HTML,
        reply_markup=_menu(settings),
        disable_web_page_preview=True,
    )


# ----------------------------------------------------------------------
# /help
# ----------------------------------------------------------------------
async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings: Settings = context.application.bot_data["settings"]
    await update.effective_message.reply_text(
        msg.HELP.format(
            limit=human_size(settings.upload_limit),
            duration=human_duration(settings.max_duration_sec),
        ),
        parse_mode=ParseMode.HTML,
        reply_markup=kb.back_menu(),
        disable_web_page_preview=True,
    )


# ----------------------------------------------------------------------
# دکمه‌های منو
# ----------------------------------------------------------------------
async def on_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """بازگشت به منوی اصلی."""
    query = update.callback_query
    await query.answer()
    settings: Settings = context.application.bot_data["settings"]
    await _safe_edit(query.message, _welcome(settings), _menu(settings))


async def on_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    settings: Settings = context.application.bot_data["settings"]
    await _safe_edit(
        query.message,
        msg.HELP.format(
            limit=human_size(settings.upload_limit),
            duration=human_duration(settings.max_duration_sec),
        ),
        kb.back_menu(),
    )


async def on_platforms(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    await _safe_edit(query.message, msg.PLATFORMS, kb.back_menu())


async def on_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    settings: Settings = context.application.bot_data["settings"]
    registry: JobRegistry = context.application.bot_data["jobs"]

    await _safe_edit(
        query.message,
        msg.STATUS.format(
            uptime=_uptime(),
            active=registry.active_count(),
            limit=human_size(settings.upload_limit),
            mode="سرور محلی" if settings.uses_local_api else "api.telegram.org",
        ),
        kb.back_menu(),
    )
