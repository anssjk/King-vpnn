"""وب‌سرور Mini App.

مسیرها:
    GET  /                      صفحه‌ی Mini App
    GET  /static/*              فایل‌های استاتیک (CSS/JS)
    GET  /health                بررسی سلامت
    POST /api/probe             بررسی لینک و گرفتن اطلاعات ویدیو
    POST /api/download          شروع دانلود
    GET  /api/status/{job_id}   وضعیت پیشرفت
    POST /api/cancel            لغو

همه‌ی مسیرهای /api به هدر X-Init-Data نیاز دارند که با توکن ربات
اعتبارسنجی می‌شود. بدون آن، هر کسی می‌توانست از سرور شما دانلود کند.
"""

from __future__ import annotations

import logging
from pathlib import Path

from aiohttp import web

from config import Settings
from webapp.auth import InitDataError, validate_init_data
from webapp.service import DownloadService, ServiceError

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"

# کلیدهایی که در request ذخیره می‌شوند
KEY_USER = "tg_user"
KEY_INIT = "tg_init"


# ----------------------------------------------------------------------
# میان‌افزار احراز هویت
# ----------------------------------------------------------------------
def _extract_init_data(request: web.Request) -> str:
    """initData را از هدر یا بدنه می‌گیرد.

    هدر X-Init-Data روش اصلی است؛ اگر نبود، از query هم می‌پذیریم
    (برای دیباگ با curl).
    """
    raw = request.headers.get("X-Init-Data", "").strip()
    if raw:
        return raw
    return request.query.get("init_data", "").strip()


@web.middleware
async def auth_middleware(request: web.Request, handler):
    """مسیرهای /api را محافظت می‌کند."""
    if not request.path.startswith("/api/"):
        return await handler(request)

    settings: Settings = request.app["settings"]
    raw = _extract_init_data(request)

    if not raw:
        return web.json_response(
            {"error": "unauthorized", "message": "initData ارسال نشده است."},
            status=401,
        )

    try:
        init = validate_init_data(raw, settings.bot_token)
    except InitDataError as exc:
        logger.warning("initData رد شد: %s", exc)
        return web.json_response(
            {"error": "unauthorized", "message": "اعتبارسنجی تلگرام ناموفق بود."},
            status=401,
        )

    request[KEY_USER] = init.user
    request[KEY_INIT] = init
    return await handler(request)


@web.middleware
async def error_middleware(request: web.Request, handler):
    """ServiceError را به JSON تمیز تبدیل می‌کند."""
    try:
        return await handler(request)
    except ServiceError as exc:
        return web.json_response(
            {"error": exc.code, "message": exc.message},
            status=exc.status,
        )
    except web.HTTPException:
        raise
    except Exception:  # noqa: BLE001
        logger.exception("خطای پیش‌بینی‌نشده در %s %s", request.method, request.path)
        return web.json_response(
            {"error": "internal", "message": "خطای داخلی سرور."},
            status=500,
        )


# ----------------------------------------------------------------------
# صفحه‌ها
# ----------------------------------------------------------------------
async def index(request: web.Request) -> web.StreamResponse:
    path = STATIC_DIR / "index.html"
    if not path.is_file():
        return web.Response(text="index.html پیدا نشد", status=500)
    return web.FileResponse(
        path,
        headers={
            # Mini App داخل iframe تلگرام باز می‌شود
            "Cache-Control": "no-cache",
        },
    )


async def health(request: web.Request) -> web.Response:
    service: DownloadService = request.app["service"]
    return web.json_response(
        {
            "status": "ok",
            "active": service.active_count(),
        }
    )


# ----------------------------------------------------------------------
# API
# ----------------------------------------------------------------------
async def api_probe(request: web.Request) -> web.Response:
    """بررسی لینک و برگرداندن اطلاعات ویدیو."""
    service: DownloadService = request.app["service"]
    user = request[KEY_USER]

    try:
        payload = await request.json()
    except Exception:  # noqa: BLE001
        raise ServiceError("bad_json", "بدنه‌ی درخواست JSON معتبر نیست.", 400)

    url = str(payload.get("url") or "").strip()
    if not url:
        raise ServiceError("no_url", "لینک را وارد کن.", 400)

    job = await service.create_job(chat_id=user.id, user_id=user.id)
    await service.probe(job, url)
    return web.json_response(job.to_dict())


async def api_download(request: web.Request) -> web.Response:
    """شروع دانلود با کیفیت انتخاب‌شده."""
    service: DownloadService = request.app["service"]
    user = request[KEY_USER]

    try:
        payload = await request.json()
    except Exception:  # noqa: BLE001
        raise ServiceError("bad_json", "بدنه‌ی درخواست JSON معتبر نیست.", 400)

    job_id = str(payload.get("job_id") or "").strip()
    if not job_id:
        raise ServiceError("no_job", "شناسه‌ی کار ارسال نشده.", 400)

    job = service.get_for_user(job_id, user.id)

    audio_only = bool(payload.get("audio_only") or False)
    height: int | None = None

    raw_height = payload.get("height")
    if raw_height not in (None, "", "best"):
        try:
            height = int(raw_height)
        except (TypeError, ValueError) as exc:
            raise ServiceError("bad_height", "کیفیت انتخاب‌شده معتبر نیست.", 400) from exc
        if height <= 0:
            raise ServiceError("bad_height", "کیفیت انتخاب‌شده معتبر نیست.", 400)

    await service.start_download(job, height=height, audio_only=audio_only)
    return web.json_response(job.to_dict())


async def api_status(request: web.Request) -> web.Response:
    """وضعیت پیشرفت یک کار."""
    service: DownloadService = request.app["service"]
    user = request[KEY_USER]

    job_id = request.match_info.get("job_id", "")
    job = service.get_for_user(job_id, user.id)
    return web.json_response(job.to_dict())


async def api_cancel(request: web.Request) -> web.Response:
    """لغو دانلود در جریان."""
    service: DownloadService = request.app["service"]
    user = request[KEY_USER]

    try:
        payload = await request.json()
    except Exception:  # noqa: BLE001
        raise ServiceError("bad_json", "بدنه‌ی درخواست JSON معتبر نیست.", 400)

    job_id = str(payload.get("job_id") or "").strip()
    if not job_id:
        raise ServiceError("no_job", "شناسه‌ی کار ارسال نشده.", 400)

    job = service.get_for_user(job_id, user.id)
    await service.cancel(job)
    return web.json_response(job.to_dict())


# ----------------------------------------------------------------------
# ساخت اپلیکیشن
# ----------------------------------------------------------------------
def create_app(settings: Settings, service: DownloadService) -> web.Application:
    app = web.Application(
        middlewares=[error_middleware, auth_middleware],
        client_max_size=1024 * 1024,  # ۱ مگابایت برای بدنه‌ی JSON کافی است
    )
    app["settings"] = settings
    app["service"] = service

    app.router.add_get("/", index)
    app.router.add_get("/health", health)
    app.router.add_static("/static/", STATIC_DIR, name="static")

    app.router.add_post("/api/probe", api_probe)
    app.router.add_post("/api/download", api_download)
    app.router.add_get("/api/status/{job_id}", api_status)
    app.router.add_post("/api/cancel", api_cancel)

    return app
