"""سرویس دانلود برای Mini App.

این لایه بین وب‌سرور و موتور دانلود می‌نشیند:
    - کار می‌سازد و وضعیتش را نگه می‌دارد
    - دانلود را در پس‌زمینه اجرا می‌کند
    - فایل را با «فرستنده»ی تزریق‌شده به چت تلگرام می‌فرستد

چرا فرستنده تزریق می‌شود؟
    سرویس نباید به python-telegram-bot وابسته باشد. ربات یک تابع
    async می‌دهد که فایل را می‌فرستد؛ تست هم می‌تواند تابع ساختگی بدهد.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Awaitable, Callable

from config import Settings
from downloader import (
    DownloadCancelled,
    DownloadError,
    DownloadErrorKind,
    Downloader,
    DownloadResult,
    InvalidLink,
    UnsupportedSite,
    available_heights,
    parse_link,
)
from utils.files import human_duration, human_size, remove_tree
from utils.progress import ProgressTracker

logger = logging.getLogger(__name__)

# کارها بعد از این مدت منقضی می‌شوند (ثانیه)
WEB_JOB_TTL = 30 * 60

# امضای فرستنده: (chat_id, result) -> None
Sender = Callable[[int, DownloadResult], Awaitable[None]]


class JobState(str, Enum):
    QUEUED = "queued"
    PROBING = "probing"
    READY = "ready"          # اطلاعات آماده است، منتظر انتخاب کیفیت
    DOWNLOADING = "downloading"
    UPLOADING = "uploading"
    DONE = "done"
    CANCELLED = "cancelled"
    ERROR = "error"


# وضعیت‌هایی که دیگر تغییر نمی‌کنند
TERMINAL = {JobState.DONE, JobState.CANCELLED, JobState.ERROR}


@dataclass
class WebJob:
    job_id: str
    chat_id: int
    user_id: int
    url: str = ""
    platform: str = ""
    title: str = ""
    duration: int | None = None
    heights: list[int] = field(default_factory=list)
    thumbnail: str = ""
    state: JobState = JobState.QUEUED
    error_kind: str = ""
    error_text: str = ""
    percent: float = 0.0
    downloaded: int = 0
    total: int = 0
    speed: float = 0.0
    filesize: int = 0
    created_at: float = field(default_factory=time.time)
    finished_at: float | None = None

    # کنترل اجرا
    # threading.Event است نه asyncio.Event: yt-dlp در ترد جدا اجرا می‌شود و
    # باید همان پرچم را ببیند. ست کردنش از حلقه‌ی asyncio هم امن است.
    cancel_event: threading.Event = field(default_factory=threading.Event)
    task: asyncio.Task | None = None

    @property
    def expired(self) -> bool:
        return (time.time() - self.created_at) > WEB_JOB_TTL

    @property
    def cancelled(self) -> bool:
        return self.cancel_event.is_set()

    def cancel(self) -> None:
        self.cancel_event.set()

    def to_dict(self) -> dict:
        """خروجی JSON برای فرانت‌اند."""
        return {
            "job_id": self.job_id,
            "state": self.state.value,
            "url": self.url,
            "platform": self.platform,
            "title": self.title,
            "duration": self.duration,
            "duration_text": human_duration(self.duration),
            "heights": self.heights,
            "thumbnail": self.thumbnail,
            "percent": round(self.percent, 1),
            "downloaded": self.downloaded,
            "downloaded_text": human_size(self.downloaded),
            "total": self.total,
            "total_text": human_size(self.total) if self.total else "",
            "speed": int(self.speed),
            "speed_text": f"{human_size(int(self.speed))}/s" if self.speed else "",
            "filesize": self.filesize,
            "filesize_text": human_size(self.filesize) if self.filesize else "",
            "error_kind": self.error_kind,
            "error_text": self.error_text,
            "cancellable": self.state in {
                JobState.QUEUED,
                JobState.PROBING,
                JobState.DOWNLOADING,
                JobState.UPLOADING,
            },
        }


class ServiceError(Exception):
    """خطای قابل نمایش به فرانت‌اند."""

    def __init__(self, code: str, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


class DownloadService:
    """نگه‌دارنده‌ی کارها + اجرای دانلود در پس‌زمینه."""

    def __init__(
        self,
        settings: Settings,
        downloader: Downloader,
        sender: Sender | None = None,
    ) -> None:
        self.settings = settings
        self.downloader = downloader
        self.sender = sender
        self._jobs: dict[str, WebJob] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # مدیریت کارها
    # ------------------------------------------------------------------
    def _purge(self) -> None:
        stale = [k for k, j in self._jobs.items() if j.expired and j.state in TERMINAL]
        for key in stale:
            self._jobs.pop(key, None)

    async def create_job(self, chat_id: int, user_id: int) -> WebJob:
        async with self._lock:
            self._purge()
            job = WebJob(
                job_id=uuid.uuid4().hex[:12],
                chat_id=chat_id,
                user_id=user_id,
            )
            self._jobs[job.job_id] = job
            return job

    def get(self, job_id: str) -> WebJob | None:
        job = self._jobs.get(job_id)
        if job is None:
            return None
        if job.expired and job.state in TERMINAL:
            self._jobs.pop(job_id, None)
            return None
        return job

    def get_for_user(self, job_id: str, user_id: int) -> WebJob:
        """کار را می‌گیرد و مطمئن می‌شود مال همین کاربر است."""
        job = self.get(job_id)
        if job is None:
            raise ServiceError("job_not_found", "این کار پیدا نشد یا منقضی شده است.", 404)
        if job.user_id != user_id:
            raise ServiceError("forbidden", "این کار به شما تعلق ندارد.", 403)
        return job

    def active_count(self) -> int:
        return sum(
            1
            for j in self._jobs.values()
            if j.state in {JobState.DOWNLOADING, JobState.UPLOADING}
        )

    # ------------------------------------------------------------------
    # ۱) بررسی لینک
    # ------------------------------------------------------------------
    async def probe(self, job: WebJob, url: str) -> WebJob:
        """لینک را بررسی می‌کند و اطلاعات ویدیو را در کار می‌گذارد."""
        try:
            link = parse_link(url)
        except InvalidLink as exc:
            raise ServiceError("invalid_link", "لینک معتبر نیست. آدرس کامل ویدیو را بفرست.", 400) from exc
        except UnsupportedSite as exc:
            raise ServiceError(
                "unsupported_site",
                "این سایت پشتیبانی نمی‌شود. فقط یوتیوب، اینستاگرام و تیک‌تاک.",
                400,
            ) from exc

        job.url = link.url
        job.platform = link.platform
        job.state = JobState.PROBING

        try:
            info = await self.downloader.probe(link.url)
        except DownloadError as exc:
            job.state = JobState.ERROR
            job.error_kind = exc.kind.value
            job.error_text = _error_text(exc.kind)
            raise ServiceError("probe_failed", job.error_text, 422) from exc

        if info.get("_type") == "playlist":
            entries = [e for e in (info.get("entries") or []) if e]
            info = entries[0] if entries else {}

        if not info:
            job.state = JobState.ERROR
            job.error_kind = DownloadErrorKind.NOT_FOUND.value
            job.error_text = _error_text(DownloadErrorKind.NOT_FOUND)
            raise ServiceError("not_found", job.error_text, 404)

        # --- محدودیت مدت ---
        duration = info.get("duration")
        if self.settings.max_duration_sec and duration and duration > self.settings.max_duration_sec:
            job.state = JobState.ERROR
            job.error_kind = DownloadErrorKind.TOO_LONG.value
            job.error_text = (
                f"ویدیو طولانی‌تر از حد مجاز است "
                f"(حداکثر {human_duration(self.settings.max_duration_sec)})."
            )
            raise ServiceError("too_long", job.error_text, 422)

        # --- محدودیت حجم تقریبی ---
        approx = info.get("filesize") or info.get("filesize_approx")
        if approx and approx > self.settings.upload_limit:
            job.state = JobState.ERROR
            job.error_kind = DownloadErrorKind.TOO_LARGE.value
            job.error_text = _too_large_text(approx, self.settings)
            raise ServiceError("too_large", job.error_text, 422)

        job.title = (info.get("title") or "ویدیو").strip()[:200]
        job.duration = duration
        job.heights = available_heights(info)
        job.thumbnail = info.get("thumbnail") or ""
        job.state = JobState.READY
        return job

    # ------------------------------------------------------------------
    # ۲) شروع دانلود
    # ------------------------------------------------------------------
    async def start_download(
        self,
        job: WebJob,
        *,
        height: int | None = None,
        audio_only: bool = False,
    ) -> WebJob:
        if job.state in {JobState.DOWNLOADING, JobState.UPLOADING}:
            raise ServiceError("busy", "این دانلود در حال اجراست.", 409)
        if job.state in TERMINAL:
            raise ServiceError("finished", "این کار تمام شده است. لینک جدیدی بفرست.", 409)
        if not job.url:
            raise ServiceError("no_url", "اول لینک را بررسی کن.", 400)

        job.cancel_event.clear()
        job.state = JobState.DOWNLOADING
        job.percent = 0.0
        job.downloaded = 0
        job.total = 0
        job.speed = 0.0
        job.error_kind = ""
        job.error_text = ""

        job.task = asyncio.create_task(
            self._run(job, height=height, audio_only=audio_only)
        )
        return job

    async def _run(
        self,
        job: WebJob,
        *,
        height: int | None,
        audio_only: bool,
    ) -> None:
        """اجرای واقعی: دانلود، سپس ارسال به تلگرام."""
        job_dir = self.settings.download_dir / f"web-{job.job_id}"
        job_dir.mkdir(parents=True, exist_ok=True)

        tracker = ProgressTracker()
        progress_task = asyncio.create_task(self._progress_loop(job, tracker))

        try:
            result = await self.downloader.download(
                job.url,
                job_dir,
                tracker,
                height=height,
                audio_only=audio_only,
                cancel_event=job.cancel_event,
            )
        except DownloadCancelled:
            job.state = JobState.CANCELLED
            job.error_text = "دانلود لغو شد."
            return
        except DownloadError as exc:
            job.state = JobState.ERROR
            job.error_kind = exc.kind.value
            job.error_text = _error_text(exc.kind)
            return
        except Exception:  # noqa: BLE001
            logger.exception("خطای پیش‌بینی‌نشده در دانلود وب")
            job.state = JobState.ERROR
            job.error_kind = DownloadErrorKind.UNKNOWN.value
            job.error_text = _error_text(DownloadErrorKind.UNKNOWN)
            return
        finally:
            progress_task.cancel()
            try:
                await progress_task
            except asyncio.CancelledError:
                pass

        # --- حجم واقعی ---
        if result.filesize > self.settings.upload_limit:
            job.state = JobState.ERROR
            job.error_kind = DownloadErrorKind.TOO_LARGE.value
            job.error_text = _too_large_text(result.filesize, self.settings)
            remove_tree(job_dir)
            return

        job.filesize = result.filesize
        job.percent = 100.0
        job.state = JobState.UPLOADING

        # --- ارسال به چت ---
        if self.sender is None:
            job.state = JobState.ERROR
            job.error_text = "ارسال به تلگرام تنظیم نشده است."
            remove_tree(job_dir)
            return

        try:
            await self.sender(job.chat_id, result)
        except Exception:  # noqa: BLE001
            logger.exception("ارسال فایل به تلگرام ناموفق بود")
            job.state = JobState.ERROR
            job.error_kind = "send_failed"
            job.error_text = "ارسال فایل به تلگرام ناموفق بود."
            return
        finally:
            remove_tree(job_dir)

        job.state = JobState.DONE
        job.finished_at = time.time()

    async def _progress_loop(self, job: WebJob, tracker: ProgressTracker) -> None:
        """وضعیت پیشرفت را از ترد yt-dlp به کار منتقل می‌کند."""
        while True:
            await asyncio.sleep(0.5)
            state = tracker.snapshot()
            job.downloaded = state.downloaded
            job.total = state.total
            job.speed = state.speed
            job.percent = state.percent
            if state.status == "finished":
                job.percent = 100.0

    # ------------------------------------------------------------------
    # ۳) لغو
    # ------------------------------------------------------------------
    async def cancel(self, job: WebJob) -> WebJob:
        if job.state in TERMINAL:
            raise ServiceError("finished", "این کار تمام شده است.", 409)
        job.cancel()
        if job.task is not None and not job.task.done():
            # به دانلود فرصت می‌دهیم تمیز متوقف شود
            try:
                await asyncio.wait_for(asyncio.shield(job.task), timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
        if job.state not in TERMINAL:
            job.state = JobState.CANCELLED
            job.error_text = "دانلود لغو شد."
        return job


# ----------------------------------------------------------------------
# ابزارها
# ----------------------------------------------------------------------
def _error_text(kind: DownloadErrorKind) -> str:
    return {
        DownloadErrorKind.PRIVATE: "این ویدیو خصوصی است یا دسترسی به آن بسته شده.",
        DownloadErrorKind.UNAVAILABLE: "ویدیو در دسترس نیست — حذف شده یا در کشور شما محدود شده.",
        DownloadErrorKind.LOGIN_REQUIRED: "این محتوا نیاز به ورود دارد. برای اینستاگرام، ادمین باید کوکی تنظیم کند.",
        DownloadErrorKind.BOT_CHECK: "یوتیوب موقتاً درخواست‌های سرور را محدود کرده. چند دقیقه بعد امتحان کن.",
        DownloadErrorKind.NOT_FOUND: "محتوایی پیدا نشد. لینک را بررسی کن.",
        DownloadErrorKind.NETWORK: "خطا در اتصال. اتصال سرور را بررسی کن.",
        DownloadErrorKind.TOO_LONG: "ویدیو طولانی‌تر از حد مجاز است.",
        DownloadErrorKind.TOO_LARGE: "حجم فایل زیاد است.",
        DownloadErrorKind.UNSUPPORTED: "این سایت پشتیبانی نمی‌شود.",
    }.get(kind, "خطای پیش‌بینی‌نشده. دوباره امتحان کن.")


def _too_large_text(size: int, settings: Settings) -> str:
    limit = human_size(settings.upload_limit)
    if settings.uses_local_api:
        return (
            f"حجم فایل {human_size(size)} است و از سقف {limit} بیشتر است. "
            "کیفیت پایین‌تر را انتخاب کن."
        )
    return (
        f"حجم فایل {human_size(size)} است و از سقف {limit} بیشتر است. "
        "تلگرام برای ربات‌ها سقف ۵۰ مگابایت دارد؛ برای فایل‌های بزرگ‌تر ادمین باید "
        "سرور محلی Bot API را فعال کند."
    )
