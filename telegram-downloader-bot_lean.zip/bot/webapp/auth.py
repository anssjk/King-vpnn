"""اعتبارسنجی initData تلگرام.

چرا لازم است؟
Mini App یک صفحه‌ی وب است و هر کسی می‌تواند آدرسش را باز کند. اگر بک‌اند
بدون بررسی به درخواست‌ها جواب بدهد، هر کسی می‌تواند از سرور شما دانلود کند.
تلگرام با هر باز شدن Mini App یک رشته‌ی امضاشده (initData) می‌دهد که فقط
با توکن ربات قابل تأیید است.

الگوریتم رسمی تلگرام:
    secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
    hash       = HMAC_SHA256(key=secret_key,   msg=data_check_string)

نکته‌ی مهم: در مرحله‌ی اول، «WebAppData» کلید است و توکن پیام؛ برعکس
آنچه شهود می‌گوید. جابه‌جا کردنشان شایع‌ترین باگ این بخش است.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from urllib.parse import parse_qsl

# حداکثر عمر initData (ثانیه). تلگرام خودش هم تاریخ می‌دهد؛ ما سخت‌گیرانه‌تریم.
MAX_AUTH_AGE = 24 * 60 * 60


class InitDataError(ValueError):
    """initData نامعتبر، منقضی یا دست‌کاری‌شده است."""


@dataclass(frozen=True)
class TelegramUser:
    id: int
    first_name: str = ""
    last_name: str = ""
    username: str = ""
    language_code: str = ""
    is_premium: bool = False

    @property
    def display_name(self) -> str:
        full = f"{self.first_name} {self.last_name}".strip()
        return full or self.username or str(self.id)


@dataclass(frozen=True)
class InitData:
    user: TelegramUser
    auth_date: int
    query_id: str = ""
    raw: dict[str, str] | None = None


# ----------------------------------------------------------------------
# امضا
# ----------------------------------------------------------------------
def _secret_key(bot_token: str) -> bytes:
    """secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)"""
    return hmac.new(
        b"WebAppData",
        bot_token.encode(),
        hashlib.sha256,
    ).digest()


def compute_hash(data_check_string: str, bot_token: str) -> str:
    """هش موردانتظار را برای رشته‌ی مرتب‌شده حساب می‌کند."""
    return hmac.new(
        _secret_key(bot_token),
        data_check_string.encode(),
        hashlib.sha256,
    ).hexdigest()


def _data_check_string(pairs: list[tuple[str, str]]) -> str:
    """همه‌ی جفت‌ها به‌جز hash، مرتب‌شده بر اساس کلید، با \\n."""
    return "\n".join(f"{k}={v}" for k, v in sorted(pairs) if k != "hash")


# ----------------------------------------------------------------------
# تجزیه
# ----------------------------------------------------------------------
def parse_init_data(raw: str) -> dict[str, str]:
    """رشته‌ی initData را به دیکشنری تبدیل می‌کند (بدون بررسی امضا)."""
    if not raw or not raw.strip():
        raise InitDataError("initData خالی است")

    try:
        pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=False)
    except ValueError as exc:
        raise InitDataError("initData قابل تجزیه نیست") from exc

    if not pairs:
        raise InitDataError("initData هیچ فیلدی ندارد")

    return dict(pairs)


def _parse_user(raw_user: str) -> TelegramUser:
    try:
        payload = json.loads(raw_user)
    except (TypeError, ValueError) as exc:
        raise InitDataError("فیلد user معتبر نیست") from exc

    if not isinstance(payload, dict) or "id" not in payload:
        raise InitDataError("فیلد user شناسه ندارد")

    try:
        user_id = int(payload["id"])
    except (TypeError, ValueError) as exc:
        raise InitDataError("شناسه‌ی کاربر عدد نیست") from exc

    return TelegramUser(
        id=user_id,
        first_name=str(payload.get("first_name") or ""),
        last_name=str(payload.get("last_name") or ""),
        username=str(payload.get("username") or ""),
        language_code=str(payload.get("language_code") or ""),
        is_premium=bool(payload.get("is_premium") or False),
    )


# ----------------------------------------------------------------------
# اعتبارسنجی کامل
# ----------------------------------------------------------------------
def validate_init_data(
    raw: str,
    bot_token: str,
    *,
    max_age: int = MAX_AUTH_AGE,
    now: int | None = None,
) -> InitData:
    """initData را بررسی می‌کند و کاربر را برمی‌گرداند.

    خطاها:
        InitDataError — امضا نامعتبر، منقضی، یا فیلدهای ناقص.
    """
    if not bot_token:
        raise InitDataError("توکن ربات تنظیم نشده است")

    fields = parse_init_data(raw)

    received_hash = fields.get("hash", "")
    if not received_hash:
        raise InitDataError("فیلد hash وجود ندارد")

    # --- امضا ---
    pairs = list(fields.items())
    check_string = _data_check_string(pairs)
    expected = compute_hash(check_string, bot_token)

    # مقایسه‌ی زمان‌ثابت تا از حمله‌ی زمان‌سنجی جلوگیری شود
    if not hmac.compare_digest(expected, received_hash):
        raise InitDataError("امضای initData نامعتبر است")

    # --- تازگی ---
    raw_auth_date = fields.get("auth_date", "")
    try:
        auth_date = int(raw_auth_date)
    except (TypeError, ValueError) as exc:
        raise InitDataError("auth_date معتبر نیست") from exc

    current = int(now if now is not None else time.time())
    if auth_date > current + 60:
        raise InitDataError("auth_date در آینده است")
    if max_age > 0 and (current - auth_date) > max_age:
        raise InitDataError("initData منقضی شده است")

    # --- کاربر ---
    raw_user = fields.get("user", "")
    if not raw_user:
        raise InitDataError("فیلد user وجود ندارد")

    return InitData(
        user=_parse_user(raw_user),
        auth_date=auth_date,
        query_id=fields.get("query_id", ""),
        raw=fields,
    )
