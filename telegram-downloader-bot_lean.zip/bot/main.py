"""نقطه‌ی ورود واحد — ربات + وب‌سرور Mini App در یک پروسه.

مناسب Railway (و هر PaaS دیگری که یک سرویس = یک پروسه است).
هر دو بخش یک event loop، یک Downloader و یک پوشه‌ی دانلود را شریک‌اند.

اجرا:
    python main.py

اگر می‌خواهید جدا اجرا کنید، هنوز bot.py و webapp_main.py کار می‌کنند.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import sys

from aiohttp import web
from telegram.error import TelegramError

from bot import _post_init, build_application, setup_logging
from config import ConfigError, Settings, get_settings
from utils.files import human_size
from webapp.server import create_app
from webapp.service import DownloadService
from webapp_main import make_sender

logger = logging.getLogger(__name__)


def _install_signal_handlers(stop: asyncio.Event) -> None:
    """SIGTERM (که Railway موقع دیپلوی می‌فرستد) و SIGINT را می‌گیرد."""
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:  # ویندوز
            signal.signal(sig, lambda *_: stop.set())


async def run(settings: Settings) -> None:
    settings.download_dir.mkdir(parents=True, exist_ok=True)

    application = build_application(settings)

    # وب‌سرور از همان Bot و همان Downloader ربات استفاده می‌کند
    service = DownloadService(
        settings,
        application.bot_data["downloader"],
        sender=make_sender(application.bot, settings),
    )
    web_app = create_app(settings, service)
    runner = web.AppRunner(web_app)

    stop = asyncio.Event()
    _install_signal_handlers(stop)

    # ۱) اول وب‌سرور: healthcheck ریلوی باید زود جواب بگیرد
    await runner.setup()
    site = web.TCPSite(runner, settings.web_host, settings.web_port)
    await site.start()
    logger.info(
        "وب‌سرور روی %s:%d بالا آمد (سقف ارسال: %s)",
        settings.web_host,
        settings.web_port,
        human_size(settings.upload_limit),
    )

    # ۲) بعد ربات
    try:
        await application.initialize()
        await _post_init(application)
        await application.updater.start_polling(
            allowed_updates=["message", "callback_query"],
            drop_pending_updates=True,
        )
        await application.start()
        logger.info("در حال گوش دادن به تلگرام...")

        await stop.wait()
        logger.info("سیگنال خاموشی دریافت شد؛ در حال بستن...")
    finally:
        for step in (
            application.updater.stop,
            application.stop,
            application.shutdown,
        ):
            try:
                await step()
            except (TelegramError, RuntimeError):
                logger.debug("خطا هنگام خاموش کردن %s", step, exc_info=True)
        await runner.cleanup()


def main() -> int:
    try:
        settings = get_settings()
    except ConfigError as exc:
        print(f"❌ خطای تنظیمات:\n{exc}", file=sys.stderr)
        return 1

    setup_logging(settings.log_level)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)

    logger.info(
        "سقف ارسال فایل: %s | حالت: %s | Mini App: %s",
        human_size(settings.upload_limit),
        "سرور محلی" if settings.uses_local_api else "api.telegram.org",
        settings.webapp_url or "غیرفعال (WEBAPP_URL خالی است)",
    )

    asyncio.run(run(settings))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
