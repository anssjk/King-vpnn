"""نقطه‌ی ورود ربات.

اجرا:
    python bot.py
"""

from __future__ import annotations

import logging
import sys

from telegram import BotCommand
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)
from telegram.request import HTTPXRequest

from config import ConfigError, Settings, get_settings
from downloader import Downloader
from handlers import (
    cmd_help,
    cmd_start,
    handle_link,
    on_audio,
    on_cancel,
    on_error,
    on_help,
    on_menu,
    on_platforms,
    on_quality,
    on_status,
)
from utils import keyboards as kb
from utils.files import purge_old_files
from utils.jobs import JobRegistry

logger = logging.getLogger(__name__)


def setup_logging(level: str) -> None:
    logging.basicConfig(
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        level=getattr(logging, level, logging.INFO),
        stream=sys.stdout,
    )
    # httpx در هر درخواست لاگ زیادی می‌نویسد
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)


def build_application(settings: Settings) -> Application:
    """اپلیکیشن را می‌سازد. جدا شده تا در تست هم قابل استفاده باشد."""

    # تایم‌اوت‌های بلند: آپلود ویدیوی چند صد مگابایتی زمان می‌برد
    request = HTTPXRequest(
        connection_pool_size=8,
        connect_timeout=30.0,
        read_timeout=300.0,
        write_timeout=300.0,
        pool_timeout=30.0,
    )

    builder = (
        ApplicationBuilder()
        .token(settings.bot_token)
        .request(request)
        .get_updates_request(
            HTTPXRequest(connection_pool_size=4, read_timeout=60.0)
        )
        .concurrent_updates(True)
    )

    # سرور محلی Bot API برای فایل‌های بزرگ
    if settings.local_api_url:
        builder = builder.base_url(
            f"{settings.local_api_url.rstrip('/')}/bot"
        )
        builder = builder.base_file_url(
            f"{settings.local_api_url.rstrip('/')}/file/bot"
        )
        logger.info("استفاده از سرور محلی Bot API: %s", settings.local_api_url)

    application = builder.build()

    # --- وابستگی‌ها ---
    application.bot_data["settings"] = settings
    application.bot_data["downloader"] = Downloader(settings)
    application.bot_data["jobs"] = JobRegistry()

    # --- دستورها ---
    application.add_handler(CommandHandler("start", cmd_start))
    application.add_handler(CommandHandler("help", cmd_help))

    # --- دکمه‌های اینلاین ---
    # هر عمل یک الگوی regex دارد تا callback_data ناخواسته به هندلر غلط نرود
    application.add_handler(
        CallbackQueryHandler(on_menu, pattern=rf"^{kb.ACT_MENU}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_help, pattern=rf"^{kb.ACT_HELP}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_platforms, pattern=rf"^{kb.ACT_PLATFORMS}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_status, pattern=rf"^{kb.ACT_STATUS}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_quality, pattern=rf"^{kb.ACT_QUALITY}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_audio, pattern=rf"^{kb.ACT_AUDIO}:")
    )
    application.add_handler(
        CallbackQueryHandler(on_cancel, pattern=rf"^{kb.ACT_CANCEL}:")
    )

    # --- لینک ---
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_link)
    )
    application.add_error_handler(on_error)

    return application


async def _post_init(application: Application) -> None:
    """کارهای بعد از اتصال: منوی دستورها + پاک‌سازی فایل‌های قدیمی."""
    settings: Settings = application.bot_data["settings"]

    await application.bot.set_my_commands(
        [
            BotCommand("start", "شروع"),
            BotCommand("help", "راهنما"),
        ]
    )

    # --- دکمه‌ی منوی چت (کنار فیلد تایپ) که Mini App را باز می‌کند ---
    if settings.has_webapp:
        try:
            from telegram import MenuButtonWebApp, WebAppInfo

            await application.bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(
                    text="Mini App",
                    web_app=WebAppInfo(url=settings.webapp_url),
                )
            )
            logger.info("دکمه‌ی منوی Mini App ثبت شد: %s", settings.webapp_url)
        except Exception:  # noqa: BLE001 - نسخه‌های قدیمی یا آدرس نامعتبر
            logger.warning("ثبت دکمه‌ی منوی Mini App ناموفق بود", exc_info=True)

    settings.download_dir.mkdir(parents=True, exist_ok=True)
    purge_old_files(settings.download_dir, max_age_seconds=3600)

    me = await application.bot.get_me()
    logger.info("ربات @%s آماده است.", me.username)


def main() -> int:
    try:
        settings = get_settings()
    except ConfigError as exc:
        print(f"❌ خطای تنظیمات:\n{exc}", file=sys.stderr)
        return 1

    setup_logging(settings.log_level)
    settings.download_dir.mkdir(parents=True, exist_ok=True)

    logger.info(
        "سقف ارسال فایل: %s | حالت: %s",
        f"{settings.upload_limit // (1024 * 1024)} MB",
        "سرور محلی" if settings.uses_local_api else "api.telegram.org",
    )

    application = build_application(settings)
    application.post_init = _post_init

    logger.info("در حال اتصال به تلگرام...")
    application.run_polling(
        allowed_updates=["message", "callback_query"],
        drop_pending_updates=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
