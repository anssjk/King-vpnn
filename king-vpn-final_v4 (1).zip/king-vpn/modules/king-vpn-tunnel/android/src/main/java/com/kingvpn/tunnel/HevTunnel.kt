package com.kingvpn.tunnel

import android.content.Context
import hev.htproxy.TProxyService
import java.io.File

/**
 * The TUN-to-SOCKS5 bridge.
 *
 * `hev-socks5-tunnel` reads raw IP packets from the VpnService TUN file descriptor and
 * forwards them to a SOCKS5 server — here, the Xray core's local SOCKS inbound. This is
 * the piece that turns "Xray is running" into "the phone's traffic actually goes through
 * the proxy": without it the core would be listening on a port nothing feeds.
 *
 * The library is driven entirely through a YAML config file plus the TUN fd, so this
 * class only writes that file and calls the three native entry points.
 */
object HevTunnel {

  /** The local SOCKS5 port Xray listens on. Loopback only — never exposed. */
  const val SOCKS_PORT = 1080

  /** The TUN interface address the VpnService assigns. */
  const val TUN_ADDRESS = "198.18.0.1"

  @Volatile
  var lastError: String? = null

  /**
   * Build the YAML config the bridge reads.
   *
   * `mtu` matches the VpnService's own MTU so the two agree on packet size. `udp: 'udp'`
   * keeps DNS and QUIC working (a TCP-only relay would silently break name resolution).
   * `log-level: warn` keeps the log quiet in normal use but still records real problems.
   */
  private fun buildConfig(mtu: Int): String = """
    tunnel:
      name: tun0
      mtu: $mtu
      multi-queue: false
      ipv4: $TUN_ADDRESS
      icmp: 'off'

    socks5:
      port: $SOCKS_PORT
      address: 127.0.0.1
      udp: 'udp'

    misc:
      log-level: warn
      connect-timeout: 10000
      tcp-read-write-timeout: 300000
      udp-read-write-timeout: 60000
  """.trimIndent()

  /**
   * Start the bridge on an already-open TUN file descriptor.
   *
   * Returns false with `lastError` set when the native library refuses, so the caller can
   * tear the tunnel down instead of leaving a half-open interface.
   */
  fun start(context: Context, tunFd: Int, mtu: Int): Boolean {
    if (TProxyService.TProxyIsRunning()) return true
    return try {
      val file = File(context.filesDir, "hev-socks5-tunnel.yml")
      file.writeText(buildConfig(mtu))
      val ok = TProxyService.TProxyStartService(file.absolutePath, tunFd)
      if (!ok) {
        lastError = "The TUN bridge refused to start."
      } else {
        lastError = null
      }
      ok
    } catch (e: Throwable) {
      lastError = e.message ?: e.javaClass.simpleName
      false
    }
  }

  /** Stop the bridge. Safe to call when it is already stopped. */
  fun stop() {
    try {
      if (TProxyService.TProxyIsRunning()) {
        TProxyService.TProxyStopService()
      }
    } catch (_: Throwable) {
      // Already down.
    }
  }

  fun isRunning(): Boolean = try {
    TProxyService.TProxyIsRunning()
  } catch (_: Throwable) {
    false
  }

  /**
   * Real traffic counters from the bridge.
   *
   * The native call returns `[txPackets, txBytes, rxPackets, rxBytes]`. These are the
   * honest numbers for the UI: they only move when packets actually cross the tunnel.
   */
  fun stats(): LongArray = try {
    TProxyService.TProxyGetStats() ?: LongArray(4)
  } catch (_: Throwable) {
    LongArray(4)
  }
}
