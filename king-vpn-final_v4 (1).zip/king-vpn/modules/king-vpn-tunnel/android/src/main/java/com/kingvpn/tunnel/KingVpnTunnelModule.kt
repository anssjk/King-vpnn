package com.kingvpn.tunnel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.VpnService
import expo.modules.kotlin.activityresult.AppContextActivityResultContract
import expo.modules.kotlin.activityresult.AppContextActivityResultLauncher
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.functions.Coroutine
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.KeyPair
import java.net.InetAddress

/**
 * The native bridge the JavaScript layer talks to.
 *
 * The app has **two** engines, because it has two kinds of endpoint, and this module owns
 * both:
 *
 *  1. **Xray** (`connectXrayAsync` / `disconnectAsync` / `getStatusAsync`) — the real
 *     multi-protocol tunnel. It starts `KingVpnService`, which creates the TUN interface
 *     through `android.net.VpnService` and runs Xray-core behind a SOCKS5 inbound that
 *     `hev-socks5-tunnel` feeds. This is what carries VLESS, VMess, Trojan and
 *     Shadowsocks over TCP, WebSocket, gRPC, XHTTP, TLS and REALITY.
 *  2. **WireGuard/WARP** (`connectAsync`) — the Cloudflare WARP path, kept because the
 *     app's built-in nodes are WARP endpoints. `GoBackend` from
 *     `com.wireguard.android:tunnel` creates its own TUN and runs the userspace WireGuard
 *     implementation inside it.
 *
 * Both paths share the same consent dialog, the same probes and the same honest reporting:
 * a connect call resolves only once the tunnel is genuinely up, and every failure is
 * surfaced with its real reason.
 *
 * ## The probes, and why there are three
 *
 *  - `probeAsync` / `probeTcpAsync` — a real TCP connect. The right first filter for a
 *    TCP-based transport; it says nothing about whether a proxy would work.
 *  - `probeTlsAsync` — a real TLS handshake presenting `sni`. Proves the address, the port
 *    and the server name all agree.
 *  - `probeWgAsync` / `probeManyAsync` — a real WireGuard handshake. The right probe for a
 *    WARP endpoint, because WireGuard is UDP and a TCP connect to its ports is closed on
 *    every edge.
 *
 * And one test that is not a probe at all: `testConfigAsync` starts the core with a real
 * config and fetches a page *through it*. That is the only check that can honestly say a
 * config works.
 */
class KingVpnTunnelModule : Module() {

  private val context: Context
    get() = appContext.reactContext ?: throw CodedException("React context is not available")

  /** The single WireGuard tunnel this app manages. One instance, one name. */
  private val tunnel = KingTunnel()

  private var backend: Backend? = null

  /** Set by `cancelScanAsync` so a running scan stops at the next endpoint. */
  @Volatile
  private var scanCancelled = false

  /** Assigned by the activity-result registry once an Activity is available. */
  private var vpnPermissionLauncher: AppContextActivityResultLauncher<String, Boolean>? = null

  /** Lazily created so a missing native library surfaces as a clean error, not a crash. */
  private fun backend(): Backend {
    backend?.let { return it }
    val created = GoBackend(context)
    backend = created
    return created
  }

  override fun definition() = ModuleDefinition {
    Name("KingVpnTunnel")

    Events("onTunnelStateChange", "onScanProgress")

    /**
     * Register the consent-dialog launcher. `VpnService.prepare()`'s Intent must be
     * started from an Activity, so it goes through Expo's activity-result registry.
     */
    RegisterActivityContracts {
      vpnPermissionLauncher = registerForActivityResult(VpnPermissionContract())
    }

    /** True when Android has already granted this app the VPN permission. */
    AsyncFunction("isPreparedAsync") {
      // null means "already authorized"; a non-null Intent means consent is still needed.
      VpnService.prepare(context) == null
    }

    /**
     * Show the real system VPN consent dialog and resolve with the user's answer.
     * Resolves `true` only when Android actually granted the permission.
     */
    AsyncFunction("requestPermissionAsync") Coroutine { ->
      if (VpnService.prepare(context) == null) {
        return@Coroutine true
      }
      val launcher = vpnPermissionLauncher
        ?: throw CodedException("The VPN consent dialog is not ready yet. Try again in a moment.")
      launcher.launch("")
    }

    /** Generate a WireGuard key pair with the library's constant-time implementation. */
    AsyncFunction("generateKeyPairAsync") {
      val pair = KeyPair()
      mapOf(
        "privateKey" to pair.privateKey.toBase64(),
        "publicKey" to pair.publicKey.toBase64()
      )
    }

    /** The Xray core's version string, for the About screen and support reports. */
    AsyncFunction("coreVersionAsync") {
      XrayEngine.init(context)
      XrayEngine.version
    }

    // ---- WireGuard / WARP path --------------------------------------------------------

    /**
     * Bring the WireGuard tunnel up.
     *
     * `config` carries the WireGuard parameters (private key, addresses, peer). The call
     * resolves only once the backend reports the tunnel UP; if the permission is missing
     * or the config is rejected, it rejects with the real reason.
     */
    AsyncFunction("connectAsync") Coroutine { config: Map<String, Any?> ->
      if (VpnService.prepare(context) != null) {
        throw VpnPermissionMissingException()
      }
      val wgConfig = buildConfig(config)
      val state = backend().setState(tunnel, Tunnel.State.UP, wgConfig)
      if (state != Tunnel.State.UP) {
        throw TunnelStartException("The tunnel did not come up (state: $state).")
      }
      // Keep the process alive so Android does not reclaim the tunnel in the background.
      try {
        KingVpnForegroundService.start(context)
      } catch (e: Exception) {
        // The tunnel is up; a missing notification must not tear it down.
      }
      sendEvent("onTunnelStateChange", mapOf("state" to "UP"))
      true
    }

    // ---- Xray path --------------------------------------------------------------------

    /**
     * Bring the real multi-protocol tunnel up with a full Xray JSON config.
     *
     * The config is built in JavaScript from the parsed server fields, so this call is
     * protocol-agnostic: whatever the config says (VLESS over REALITY, Trojan over WS,
     * Shadowsocks, …) is what the core will speak. Resolves only once the TUN exists, the
     * core is running and the bridge is up; otherwise it rejects with the real reason.
     */
    AsyncFunction("connectXrayAsync") Coroutine { configJson: String, mtu: Int ->
      if (VpnService.prepare(context) != null) {
        throw VpnPermissionMissingException()
      }
      KingVpnService.start(context, configJson, mtu)
      // The service starts asynchronously; wait briefly for the chain to come up so the
      // caller gets a truthful answer instead of an optimistic one.
      val deadline = System.currentTimeMillis() + 8000
      while (System.currentTimeMillis() < deadline) {
        if (KingVpnService.isRunning()) {
          sendEvent("onTunnelStateChange", mapOf("state" to "UP"))
          return@Coroutine true
        }
        val err = KingVpnService.lastError
        if (err != null) {
          throw TunnelStartException(err)
        }
        Thread.sleep(120)
      }
      throw TunnelStartException(
        KingVpnService.lastError ?: "The tunnel did not come up in time."
      )
    }

    /**
     * Tear **both** engines down.
     *
     * Whichever path carried the session, this leaves nothing half-open behind: the
     * WireGuard backend is set DOWN, the Xray core is stopped and the VpnService is told
     * to stop. Safe to call when nothing is running.
     */
    AsyncFunction("disconnectAsync") Coroutine { ->
      try {
        backend().setState(tunnel, Tunnel.State.DOWN, null)
      } catch (_: Exception) {
        // Nothing was up on the WireGuard path.
      }
      try {
        KingVpnService.stop(context)
      } catch (_: Exception) {
        // Nothing was up on the Xray path.
      }
      try {
        KingVpnForegroundService.stop(context)
      } catch (_: Exception) {
        // Already stopped.
      }
      val deadline = System.currentTimeMillis() + 4000
      while (System.currentTimeMillis() < deadline && KingVpnService.isRunning()) {
        Thread.sleep(100)
      }
      sendEvent("onTunnelStateChange", mapOf("state" to "DOWN"))
      true
    }

    /**
     * The tunnel's real state plus traffic counters.
     *
     * The Xray path is reported first when it is up, because its counters come from the
     * bridge and only move when packets actually cross the tunnel. Otherwise the WireGuard
     * backend's own statistics are used, where `latestHandshakeMs` is the strongest signal
     * that the tunnel is genuinely working.
     */
    AsyncFunction("getStatusAsync") {
      if (KingVpnService.isRunning()) {
        val stats = KingVpnService.stats()
        mapOf(
          "state" to "UP",
          "rxBytes" to (stats.getOrNull(3) ?: 0L),
          "txBytes" to (stats.getOrNull(1) ?: 0L),
          "latestHandshakeMs" to System.currentTimeMillis(),
          "version" to XrayEngine.version
        )
      } else {
        val be = backend()
        val state = be.getState(tunnel)
        val stats = try {
          be.getStatistics(tunnel)
        } catch (e: Exception) {
          null
        }
        val peerKey = try {
          stats?.peers()?.firstOrNull()
        } catch (e: Exception) {
          null
        }
        val peerStats = if (peerKey != null) {
          try {
            stats?.peer(peerKey)
          } catch (e: Exception) {
            null
          }
        } else {
          null
        }
        mapOf(
          "state" to state.name,
          "rxBytes" to (peerStats?.rxBytes ?: 0L),
          "txBytes" to (peerStats?.txBytes ?: 0L),
          "latestHandshakeMs" to (peerStats?.latestHandshakeEpochMillis ?: 0L),
          "version" to (try { be.version } catch (e: Exception) { "" })
        )
      }
    }

    // ---- Probes -----------------------------------------------------------------------

    /**
     * Measure one endpoint's reachability and round-trip time with a TCP connect.
     *
     * A WARP endpoint does not answer HTTPS on a bare IP (the edge needs the right SNI),
     * so an HTTP probe reports a false failure. A TCP connect to the tunnel port measures
     * what actually matters — whether this anycast range is reachable from the current
     * network — and its handshake time is a fair latency figure. Runs off the JS thread.
     */
    AsyncFunction("probeAsync") Coroutine { host: String, port: Int, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        socket = java.net.Socket()
        socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        mapOf(
          "ok" to true,
          "ms" to (System.currentTimeMillis() - started).toInt(),
          "error" to null
        )
      } catch (e: Exception) {
        mapOf(
          "ok" to false,
          "ms" to 0,
          "error" to (e.message ?: e.javaClass.simpleName)
        )
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    /** The same TCP connect probe, under the name the Xray bridge uses. */
    AsyncFunction("probeTcpAsync") Coroutine { host: String, port: Int, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        socket = java.net.Socket()
        socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        mapOf(
          "ok" to true,
          "ms" to (System.currentTimeMillis() - started).toInt(),
          "error" to null
        )
      } catch (e: Exception) {
        mapOf("ok" to false, "ms" to 0, "error" to (e.message ?: e.javaClass.simpleName))
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    /**
     * Measure an endpoint with a real TLS handshake that presents `sni`.
     *
     * This is the probe that proves the *server name* is right, not just the address.
     * A bare anycast IP only completes a TLS handshake when the ClientHello carries the
     * name the edge serves; without it the edge resets the connection. So a successful
     * result here means the address, the port and the SNI all agree — exactly the three
     * values a TLS-based config is built from.
     */
    AsyncFunction("probeTlsAsync") Coroutine { host: String, port: Int, sni: String, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      var socket: java.net.Socket? = null
      try {
        val raw = java.net.Socket()
        socket = raw
        raw.connect(java.net.InetSocketAddress(host, port), timeoutMs)
        raw.soTimeout = timeoutMs
        val factory = javax.net.ssl.SSLContext.getDefault().socketFactory
        val ssl = factory.createSocket(raw, sni, port, true) as javax.net.ssl.SSLSocket
        ssl.sslParameters = ssl.sslParameters.apply {
          // Present the name the edge serves; this is the SNI the tunnel config carries.
          serverNames = listOf(javax.net.ssl.SNIHostName(sni))
          endpointIdentificationAlgorithm = "HTTPS"
        }
        ssl.startHandshake()
        val ms = (System.currentTimeMillis() - started).toInt()
        try {
          ssl.close()
        } catch (_: Exception) {
        }
        mapOf("ok" to true, "ms" to ms, "error" to null)
      } catch (e: Exception) {
        mapOf(
          "ok" to false,
          "ms" to 0,
          "error" to (e.message ?: e.javaClass.simpleName)
        )
      } finally {
        try {
          socket?.close()
        } catch (_: Exception) {
        }
      }
    }

    /**
     * The real test: start the core with this config and fetch a page **through it**.
     *
     * This is the only check that can honestly say a config works. It starts Xray with the
     * given JSON, opens a SOCKS5 connection to the core's loopback port, requests
     * Cloudflare's trace endpoint through the proxy, and reads the exit IP the server
     * reports. A success means the handshake, the transport and the outbound all work and
     * traffic genuinely left through the server. The core is stopped again afterwards.
     */
    AsyncFunction("testConfigAsync") Coroutine { configJson: String, timeoutMs: Int ->
      val started = System.currentTimeMillis()
      if (!XrayEngine.start(context, configJson)) {
        return@Coroutine mapOf(
          "ok" to false,
          "ms" to 0,
          "ip" to null,
          "error" to (XrayEngine.lastError ?: "The core did not start.")
        )
      }
      try {
        // Give the core a moment to bind its SOCKS port.
        Thread.sleep(400)
        val result = SocksProbe.fetchThroughSocks(
          socksPort = HevTunnel.SOCKS_PORT,
          host = "1.1.1.1",
          port = 80,
          path = "/cdn-cgi/trace",
          timeoutMs = timeoutMs
        )
        val ms = (System.currentTimeMillis() - started).toInt()
        if (!result.ok) {
          return@Coroutine mapOf("ok" to false, "ms" to ms, "ip" to null, "error" to result.error)
        }
        mapOf("ok" to true, "ms" to ms, "ip" to result.ip, "error" to null)
      } finally {
        XrayEngine.stop()
      }
    }

    /**
     * Probe one endpoint with a **real WireGuard handshake**.
     *
     * This is the scanner's probe for WARP endpoints. It sends a genuine Noise IK
     * initiation over UDP and waits for the peer's response, so a success means the
     * address, the port and the peer key are all correct — the exact triple the tunnel
     * config is built from.
     *
     * A TCP connect cannot work here: WireGuard is UDP, so TCP on 2408/500/1701/4500 is
     * closed on every WARP edge and every healthy endpoint would be reported as
     * unreachable.
     */
    AsyncFunction("probeWgAsync") Coroutine { host: String, port: Int, privateKey: String, peerPublicKey: String, timeoutMs: Int ->
      val result = WgProbe.probeOne(
        host = host,
        port = port,
        privateKey = decodeKey(privateKey),
        peerPublicKey = decodeKey(peerPublicKey),
        timeoutMs = timeoutMs
      )
      mapOf(
        "ok" to result.ok,
        "ms" to (result.ms ?: 0),
        "error" to result.error,
        "port" to result.port,
        "colo" to result.colo,
        "loc" to result.loc
      )
    }

    /**
     * Probe many endpoints concurrently with real handshakes, streaming each result.
     *
     * `endpoints` is a list of `{ host, port }`. Every result is emitted as an
     * `onScanProgress` event as soon as it lands, so the list fills in live instead of
     * appearing all at once at the end. Each result carries its own host, so a row can
     * never show another endpoint's address.
     */
    AsyncFunction("probeManyAsync") Coroutine { endpoints: List<Map<String, Any?>>, privateKey: String, peerPublicKey: String, timeoutMs: Int, concurrency: Int, resolveColo: Boolean ->
      scanCancelled = false
      val priv = decodeKey(privateKey)
      val peer = decodeKey(peerPublicKey)
      val list = endpoints.mapNotNull { entry ->
        val h = (entry["host"] as? String)?.trim().orEmpty()
        if (h.isEmpty()) null else h to ((entry["port"] as? Number)?.toInt() ?: 2408)
      }
      val results = WgProbe.probeMany(
        endpoints = list,
        privateKey = priv,
        peerPublicKey = peer,
        timeoutMs = timeoutMs,
        concurrency = concurrency,
        resolveColo = resolveColo,
        onResult = { r ->
          sendEvent(
            "onScanProgress",
            mapOf(
              "host" to r.host,
              "port" to r.port,
              "ok" to r.ok,
              "ms" to (r.ms ?: 0),
              "error" to r.error,
              "colo" to r.colo,
              "loc" to r.loc
            )
          )
        },
        shouldStop = { scanCancelled }
      )
      results.map { r ->
        mapOf(
          "host" to r.host,
          "port" to r.port,
          "ok" to r.ok,
          "ms" to (r.ms ?: 0),
          "error" to r.error,
          "colo" to r.colo,
          "loc" to r.loc
        )
      }
    }

    /** Stop a running scan at the next endpoint. */
    AsyncFunction("cancelScanAsync") {
      scanCancelled = true
      true
    }

    /**
     * Read the Cloudflare data centre an endpoint routes to, through that exact address.
     * Returns `{ colo, loc }`; both are null when the trace could not be read.
     */
    AsyncFunction("resolveColoAsync") Coroutine { host: String, timeoutMs: Int ->
      val (colo, loc) = WgProbe.resolveColo(host, timeoutMs)
      mapOf("colo" to colo, "loc" to loc)
    }

    OnDestroy {
      try {
        backend?.setState(tunnel, Tunnel.State.DOWN, null)
      } catch (_: Exception) {
        // Nothing to do: the process is going away and the system drops the tunnel.
      }
      try {
        KingVpnService.stop(context)
      } catch (_: Exception) {
        // Already stopped.
      }
      try {
        XrayEngine.stop()
      } catch (_: Exception) {
        // Already stopped.
      }
      try {
        KingVpnForegroundService.stop(context)
      } catch (_: Exception) {
        // Already stopped.
      }
    }
  }

  /** Decode a base64 WireGuard key, with a clear error when it is malformed. */
  private fun decodeKey(value: String): ByteArray {
    return try {
      java.util.Base64.getDecoder().decode(value.trim())
    } catch (e: Exception) {
      throw CodedException("A WireGuard key was not valid base64: ${e.message}")
    }
  }

  /**
   * Turn the JavaScript config map into a WireGuard `Config`.
   *
   * Every field is validated by the library, so a malformed key or address produces a
   * precise `BadConfigException` instead of a tunnel that silently fails to pass traffic.
   */
  private fun buildConfig(raw: Map<String, Any?>): Config {
    val privateKey = raw["privateKey"] as? String
      ?: throw CodedException("privateKey is required")
    val peerPublicKey = raw["peerPublicKey"] as? String
      ?: throw CodedException("peerPublicKey is required")
    val endpoint = raw["endpoint"] as? String
      ?: throw CodedException("endpoint is required")

    val addresses = (raw["addresses"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val dns = (raw["dns"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val allowedIps = (raw["allowedIps"] as? List<*>)?.filterIsInstance<String>().orEmpty()
    val mtu = (raw["mtu"] as? Number)?.toInt() ?: 1280
    val keepalive = (raw["persistentKeepalive"] as? Number)?.toInt() ?: 25
    // The server name the endpoint was validated against. WireGuard itself is not TLS,
    // so this is not part of the handshake — it is logged so a support report shows the
    // exact address/port/SNI triple the tunnel was built from.
    val sni = (raw["sni"] as? String)?.trim().orEmpty()
    if (sni.isNotEmpty()) {
      android.util.Log.i("KingVpnTunnel", "tunnel endpoint=$endpoint sni=$sni")
    }

    try {
      val ifaceBuilder = Interface.Builder()
        .parsePrivateKey(privateKey)
        .setMtu(mtu)

      for (address in addresses) {
        ifaceBuilder.addAddress(InetNetwork.parse(address))
      }
      for (server in dns) {
        ifaceBuilder.addDnsServer(InetAddress.getByName(server))
      }

      val peerBuilder = Peer.Builder()
        .parsePublicKey(peerPublicKey)
        .parseEndpoint(endpoint)
        .setPersistentKeepalive(keepalive)

      for (allowed in allowedIps) {
        peerBuilder.addAllowedIp(InetNetwork.parse(allowed))
      }

      return Config.Builder()
        .setInterface(ifaceBuilder.build())
        .addPeer(peerBuilder.build())
        .build()
    } catch (e: BadConfigException) {
      throw CodedException("Invalid WireGuard configuration: ${e.message}")
    } catch (e: Exception) {
      throw CodedException("Could not build the tunnel configuration: ${e.message}")
    }
  }
}

/** The tunnel identity the backend tracks. One instance, one name. */
private class KingTunnel : Tunnel {
  override fun getName(): String = "kingvpn"

  override fun onStateChange(newState: Tunnel.State) {
    // The module pushes state to JavaScript from connect/disconnect, where the call
    // context is known; this callback exists because the interface requires it.
  }
}

/**
 * Launches `VpnService.prepare()`'s Intent and reports whether the user allowed it.
 *
 * `Activity.RESULT_OK` is the only outcome that means the permission was granted; a
 * back-press or "Cancel" comes back as `RESULT_CANCELED` and must not be treated as
 * success.
 */
private class VpnPermissionContract : AppContextActivityResultContract<String, Boolean> {

  override fun createIntent(context: Context, input: String): Intent {
    // prepare() is guaranteed non-null here: the caller checks it before launching.
    return VpnService.prepare(context) ?: Intent()
  }

  override fun parseResult(input: String, resultCode: Int, intent: Intent?): Boolean {
    return resultCode == Activity.RESULT_OK
  }
}

class VpnPermissionMissingException :
  CodedException("Android has not granted VPN permission. Accept the system connection request first.")

class TunnelStartException(message: String) : CodedException(message)
