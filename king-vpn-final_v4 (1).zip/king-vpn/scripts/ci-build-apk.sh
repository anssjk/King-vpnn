#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# ساخت APK اندروید روی سرور گیت‌هاب (GitHub Actions).
#
# این اسکریپت تمام کار سنگین را انجام می‌دهد تا فایل workflow کوتاه بماند و
# کپی-پیست کردنش روی گوشی راحت باشد. فایل workflow فقط این را صدا می‌زند.
#
# اجرای دستی روی کامپیوتر هم ممکن است، ولی به Android SDK و JDK 17 نیاز دارد.
# ---------------------------------------------------------------------------
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

OUT="${GITHUB_WORKSPACE:-$ROOT}/output"
mkdir -p "$OUT"

echo "==> پوشه‌ی پروژه: $ROOT"

# ۱) نصب وابستگی‌ها.
#    اول npm ci (سریع و دقیقاً از lockfile). اگر lockfile با نسخه‌ی npm رانر
#    هم‌خوان نبود یا تضاد peer dependency بود، به npm install برمی‌گردیم تا
#    بیلد به‌خاطر یک اختلاف نسخه‌ی npm نخوابد.
if [ -f package-lock.json ]; then
  if ! npm ci --no-audit --no-fund; then
    echo "::warning::npm ci نشد؛ با npm install دوباره تلاش می‌شود."
    rm -rf node_modules
    npm install --no-audit --no-fund --legacy-peer-deps
  fi
else
  npm install --no-audit --no-fund --legacy-peer-deps
fi

# ۲) دو کتابخانه‌ی نیتیو تونل (~۶۰ مگابایت) داخل zip نیستند چون از سقف آپلود
#    گیت‌هاب بزرگ‌ترند. اینجا دانلود و با SHA-256 بررسی می‌شوند.
bash scripts/fetch-native-libs.sh

# ۳) نصب NDK پین‌شده. ماژول تونل فایل .so آماده دارد، پس AGP تسک strip را
#    اجرا می‌کند و به NDK نیاز دارد؛ نسخه‌ی پیش‌فرض رانر با نسخه‌ی پروژه
#    یکی نیست و خطای مبهم می‌دهد.
NDK_VERSION="27.1.12297006"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
if [ -d "$SDK_ROOT/ndk" ] && [ ! -d "$SDK_ROOT/ndk/$NDK_VERSION" ]; then
  echo "==> نصب NDK $NDK_VERSION"
  yes | "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --install "ndk;$NDK_VERSION" > /dev/null || true
fi

# ۴) ساخت پروژه‌ی نیتیو اندروید از روی app.json
npx expo prebuild --platform android --no-install --clean

# ۵) حافظه‌ی Gradle (پیش‌فرض رانر برای این پروژه کم است)
PROPS="android/gradle.properties"
[ -f "$PROPS" ] || { echo "::error::prebuild فایل gradle.properties را نساخت."; exit 1; }
if grep -q '^org.gradle.jvmargs=' "$PROPS"; then
  sed -i 's|^org.gradle.jvmargs=.*|org.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=1g|' "$PROPS"
else
  printf '\norg.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=1g\n' >> "$PROPS"
fi

# ۶) بیلد. هیچ fallback یا || اینجا نیست تا خطای واقعی Gradle دیده شود.
cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon --stacktrace
cd "$ROOT"

# ۷) برداشتن APK
APK=$(find android/app/build/outputs/apk/release -name "*.apk" | head -n 1)
[ -n "$APK" ] || { echo "::error::هیچ APK تولید نشد."; exit 1; }
cp "$APK" "$OUT/king-vpn.apk"

# ۸) امضا. APK بدون امضا روی گوشی نصب نمی‌شود («App not installed»).
APKSIGNER=$(find "$SDK_ROOT/build-tools" -name apksigner -type f 2>/dev/null | sort -V | tail -n 1)
if [ -n "$APKSIGNER" ] && ! "$APKSIGNER" verify "$OUT/king-vpn.apk" > /dev/null 2>&1; then
  echo "==> APK امضا نشده بود؛ با keystore دیباگ امضا می‌شود."
  KS="android/app/debug.keystore"
  if [ ! -f "$KS" ]; then
    keytool -genkeypair -v -storetype PKCS12 -keystore "$KS" \
      -storepass android -alias androiddebugkey -keypass android \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -dname "CN=Android Debug,O=Android,C=US"
  fi
  "$APKSIGNER" sign --ks "$KS" --ks-pass pass:android --ks-key-alias androiddebugkey \
    --key-pass pass:android --out "$OUT/signed.apk" "$OUT/king-vpn.apk"
  mv "$OUT/signed.apk" "$OUT/king-vpn.apk"
  "$APKSIGNER" verify "$OUT/king-vpn.apk"
fi

ls -lh "$OUT/king-vpn.apk"

# ۹) خلاصه‌ی فارسی در صفحه‌ی اجرا
SIZE=$(du -h "$OUT/king-vpn.apk" | cut -f1)
{
  echo "### ✅ APK آماده شد"
  echo ""
  echo "**حجم:** $SIZE"
  echo ""
  echo "از بخش **Artifacts** پایین همین صفحه یا از تب **Releases** دانلود کنید."
} >> "${GITHUB_STEP_SUMMARY:-/dev/null}"

# ۱۰) انتشار در Releases تا لینک دانلود مستقیم و قابل باز شدن روی گوشی باشد
if [ -n "${GH_TOKEN:-}" ] && command -v gh > /dev/null 2>&1; then
  TAG="apk-${GITHUB_RUN_NUMBER:-local}"
  gh release create "$TAG" "$OUT/king-vpn.apk" \
    --title "KING VPN APK (build ${GITHUB_RUN_NUMBER:-local})" \
    --notes "APK ساخته‌شده به‌صورت خودکار از سورس‌کد. فایل king-vpn.apk را دانلود و نصب کنید." \
    --latest 2>/dev/null || gh release upload "$TAG" "$OUT/king-vpn.apk" --clobber
fi

echo "==> تمام. فایل: $OUT/king-vpn.apk"
