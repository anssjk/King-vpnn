import { Redirect } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';

import { useColors } from '@/constants/theme';
import { usePanel } from '@/lib/panel-context';

/**
 * Entry point. A first launch has no panel yet, so it goes to the setup screen; once the
 * address and token are stored, every later launch goes straight to the panel.
 *
 * The stored values are read asynchronously, so nothing is decided until they have
 * loaded — otherwise a configured user would see the setup screen flash on every start.
 */
export default function Index() {
  const colors = useColors();
  const { configured, ready } = usePanel();

  if (!ready) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return <Redirect href={configured ? '/(tabs)' : '/setup'} />;
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
