import Ionicons from '@expo/vector-icons/Ionicons';
import { Tabs } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { radius, spacing, useColors } from '@/constants/theme';
import { tapFeedback } from '@/lib/haptics';
import { useSettings } from '@/lib/settings-context';

type TabName = 'index' | 'settings' | 'third';

const ICONS: Record<TabName, { active: keyof typeof Ionicons.glyphMap; idle: keyof typeof Ionicons.glyphMap }> = {
  index: { active: 'flash', idle: 'flash-outline' },
  settings: { active: 'settings', idle: 'settings-outline' },
  third: { active: 'apps', idle: 'apps-outline' },
};

/**
 * A floating, frosted tab bar with a gradient pill behind the active tab. Three tabs:
 * Home (connect), Servers (the panel's list) and Settings.
 */
export default function TabLayout() {
  const colors = useColors();
  const { t } = useSettings();
  const insets = useSafeAreaInsets();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: 'transparent' },
        tabBarStyle: { display: 'none' },
      }}
      tabBar={(props) => {
        const labels: Record<TabName, string> = {
          index: t('tabHome'),
          settings: t('tabSettings'),
          third: t('tabThird'),
        };
        return (
          <View
            pointerEvents="box-none"
            style={[styles.barWrap, { paddingBottom: Math.max(insets.bottom, 10) }]}>
            <View style={[styles.bar, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {props.state.routes.map((route, index) => {
                const name = route.name as TabName;
                const focused = props.state.index === index;
                const icon = ICONS[name] ?? ICONS.index;
                const onPress = () => {
                  tapFeedback();
                  const event = props.navigation.emit({
                    type: 'tabPress',
                    target: route.key,
                    canPreventDefault: true,
                  });
                  if (!focused && !event.defaultPrevented) {
                    props.navigation.navigate(route.name, route.params);
                  }
                };
                return (
                  <Pressable
                    key={route.key}
                    accessibilityRole="tab"
                    accessibilityState={{ selected: focused }}
                    accessibilityLabel={labels[name]}
                    onPress={onPress}
                    style={({ pressed }) => [styles.tab, pressed && { opacity: 0.8 }]}>
                    {focused ? (
                      <LinearGradient
                        colors={colors.gradientBrand}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={styles.activePill}
                      />
                    ) : null}
                    <Ionicons
                      name={focused ? icon.active : icon.idle}
                      size={21}
                      color={focused ? '#FFFFFF' : colors.muted}
                    />
                    <Text
                      style={[
                        styles.tabLabel,
                        { color: focused ? '#FFFFFF' : colors.muted },
                        focused && styles.tabLabelActive,
                      ]}>
                      {labels[name]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        );
      }}>
      <Tabs.Screen name="index" options={{ title: t('tabHome') }} />
      <Tabs.Screen name="settings" options={{ title: t('tabSettings') }} />
      <Tabs.Screen name="third" options={{ title: t('tabThird') }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  barWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
  },
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 6,
    gap: 4,
    shadowColor: '#000',
    shadowOpacity: Platform.OS === 'ios' ? 0.22 : 0.3,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
    elevation: 16,
  },
  tab: {
    flex: 1,
    minHeight: 54,
    borderRadius: radius.lg,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
  },
  activePill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: radius.lg,
  },
  tabLabel: { fontSize: 9.5, fontWeight: '700', letterSpacing: 0.1 },
  tabLabelActive: { fontWeight: '800' },
});
