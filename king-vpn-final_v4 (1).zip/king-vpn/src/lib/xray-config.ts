/**
 * Server config parsing and Xray-core JSON generation.
 *
 * ## Why this file exists
 *
 * The app has to accept the three shapes people actually have servers in:
 *
 *  1. **Share links** — `vless://…`, `vmess://…`, `trojan://…`, `ss://…`. These are what
 *     a provider hands out, and what a QR code contains.
 *  2. **A subscription** — a URL that returns a base64 blob of those links, one per line.
 *  3. **A raw Xray JSON config** — what a self-hoster already has.
 *
 * All three are normalised into one `ServerConfig` shape, and that shape is what the
 * tunnel is built from. Keeping the parse and the build in one place means a field can
 * never be read in one format and silently dropped in another — which is exactly how a
 * config ends up "connecting" to nothing.
 *
 * ## The fields that matter
 *
 * `address`, `port`, `uuid` (or `password` for Shadowsocks/Trojan), `network`
 * (tcp/ws/grpc/xhttp), `security` (none/tls/reality), `sni`, `host`, `path`,
 * `fingerprint` and `flow`. Each one is carried through to the outbound verbatim; nothing
 * is re-derived from a default once the user's config supplied it.
 */

export type Protocol = 'vless' | 'vmess' | 'trojan' | 'shadowsocks';

export type Transport = 'tcp' | 'ws' | 'grpc' | 'xhttp' | 'httpupgrade';

export type Security = 'none' | 'tls' | 'reality';

export type ServerConfig = {
  /** Stable id for lists and selection. */
  id: string;
  /** A display name — the link's fragment, or the host when it has none. */
  name: string;
  protocol: Protocol;
  address: string;
  port: number;
  /** VLESS/VMess user id. Empty for Trojan/Shadowsocks, which use `password`. */
  uuid: string;
  /** Trojan/Shadowsocks password. Empty for VLESS/VMess. */
  password: string;
  /** Shadowsocks cipher, e.g. `aes-256-gcm`. */
  method: string;
  network: Transport;
  security: Security;
  /** TLS server name. */
  sni: string;
  /** WebSocket/gRPC host header, or the REALITY server name. */
  host: string;
  /** WebSocket/HTTP path, or the gRPC service name. */
  path: string;
  /** uTLS fingerprint, e.g. `chrome`. */
  fingerprint: string;
  /** VLESS flow, e.g. `xtls-rprx-vision`. */
  flow: string;
  /** REALITY public key (`pbk`). */
  publicKey: string;
  /** REALITY short id (`sid`). */
  shortId: string;
  /** `allowInsecure` / `skip-cert-verify`. */
  allowInsecure: boolean;
  /** The original link or JSON, kept so the user can copy it back out. */
  raw: string;
};

/** A parsed result, or the reason it could not be parsed. */
export type ParseResult =
  | { ok: true; config: ServerConfig }
  | { ok: false; error: string };

// ---------------------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------------------

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

/** Base64 → UTF-8 text, tolerating URL-safe alphabets and missing padding. */
export function base64Decode(input: string): string {
  const cleaned = input.replace(/-/g, '+').replace(/_/g, '/').replace(/\s/g, '');
  const padded = cleaned + '='.repeat((4 - (cleaned.length % 4)) % 4);
  try {
    // `atob` exists in React Native (Hermes) and in the browser.
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch {
    return '';
  }
}

function num(value: string | null | undefined, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

/**
 * A port that is actually usable.
 *
 * `num` alone accepts 99999, which is not a port at all — a link with one would parse
 * "successfully" and then fail at connect time with a confusing error. Rejecting it here
 * means the user is told the link is wrong while they are still looking at it.
 */
function validPort(value: number): boolean {
  return Number.isInteger(value) && value >= 1 && value <= 65535;
}

function str(value: string | null | undefined): string {
  return (value ?? '').trim();
}

/** A short, stable id derived from the config's identity. */
function makeId(protocol: string, address: string, port: number, user: string): string {
  const seed = `${protocol}|${address}|${port}|${user}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) | 0;
  }
  return `${protocol}-${Math.abs(hash).toString(36)}`;
}

/** Normalise the many spellings of a transport into our four. */
function normaliseNetwork(value: string): Transport {
  const v = value.toLowerCase();
  if (v === 'ws' || v === 'websocket') return 'ws';
  if (v === 'grpc' || v === 'gun') return 'grpc';
  if (v === 'xhttp' || v === 'splithttp') return 'xhttp';
  if (v === 'httpupgrade') return 'httpupgrade';
  return 'tcp';
}

function normaliseSecurity(value: string): Security {
  const v = value.toLowerCase();
  if (v === 'tls' || v === 'xtls') return 'tls';
  if (v === 'reality') return 'reality';
  return 'none';
}

// ---------------------------------------------------------------------------------------
// Link parsers
// ---------------------------------------------------------------------------------------

/**
 * Parse a `vless://` link.
 *
 * Shape: `vless://uuid@host:port?type=ws&security=tls&sni=…&host=…&path=…&fp=…&flow=…#name`
 */
function parseVless(link: string): ParseResult {
  try {
    const withoutScheme = link.slice('vless://'.length);
    const hashIndex = withoutScheme.indexOf('#');
    const name = hashIndex >= 0 ? safeDecode(withoutScheme.slice(hashIndex + 1)) : '';
    const body = hashIndex >= 0 ? withoutScheme.slice(0, hashIndex) : withoutScheme;

    const queryIndex = body.indexOf('?');
    const authority = queryIndex >= 0 ? body.slice(0, queryIndex) : body;
    const query = queryIndex >= 0 ? body.slice(queryIndex + 1) : '';

    const atIndex = authority.lastIndexOf('@');
    if (atIndex < 0) return { ok: false, error: 'A VLESS link needs a uuid@host:port.' };
    const uuid = safeDecode(authority.slice(0, atIndex));
    const hostPort = authority.slice(atIndex + 1);

    const { host, port } = splitHostPort(hostPort);
    if (!host) return { ok: false, error: 'A VLESS link has no address.' };
    if (!uuid) return { ok: false, error: 'A VLESS link needs a uuid.' };
    if (!validPort(port)) return { ok: false, error: `The port ${port} is not a valid port.` };

    const params = new URLSearchParams(query);
    const network = normaliseNetwork(str(params.get('type')));
    const security = normaliseSecurity(str(params.get('security')));
    const sni = str(params.get('sni')) || str(params.get('peer')) || str(params.get('host'));
    const hostHeader = str(params.get('host'));
    const path = str(params.get('path')) || str(params.get('serviceName'));

    return {
      ok: true,
      config: {
        id: makeId('vless', host, port, uuid),
        name: name || `${host}:${port}`,
        protocol: 'vless',
        address: host,
        port,
        uuid,
        password: '',
        method: '',
        network,
        security,
        sni,
        host: hostHeader,
        path,
        fingerprint: str(params.get('fp')),
        flow: str(params.get('flow')),
        publicKey: str(params.get('pbk')),
        shortId: str(params.get('sid')),
        allowInsecure: str(params.get('allowInsecure')) === '1',
        raw: link,
      },
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Could not parse the VLESS link.' };
  }
}

/**
 * Parse a `vmess://` link.
 *
 * VMess links are base64 of a JSON object, not a URL. The keys are short and inconsistent
 * between clients (`add`/`address`, `id`/`uuid`, `net`/`network`, `tls`/`security`), so
 * every known spelling is read.
 */
function parseVmess(link: string): ParseResult {
  try {
    const payload = link.slice('vmess://'.length).trim();
    const json = base64Decode(payload);
    if (!json) return { ok: false, error: 'The VMess link is not valid base64.' };
    const obj = JSON.parse(json) as Record<string, unknown>;

    const address = str(obj.add as string) || str(obj.address as string);
    const port = num(obj.port as string, 443);
    const uuid = str(obj.id as string) || str(obj.uuid as string);
    if (!address) return { ok: false, error: 'The VMess link has no address.' };
    if (!uuid) return { ok: false, error: 'The VMess link has no id.' };
    if (!validPort(port)) return { ok: false, error: `The port ${port} is not a valid port.` };

    const network = normaliseNetwork(str((obj.net as string) ?? (obj.network as string)));
    const tlsValue = str(obj.tls as string) || str(obj.security as string);
    const security = normaliseSecurity(tlsValue);
    const sni = str(obj.sni as string) || str(obj.host as string);
    const hostHeader = str(obj.host as string);
    const path = str(obj.path as string);

    return {
      ok: true,
      config: {
        id: makeId('vmess', address, port, uuid),
        name: str(obj.ps as string) || `${address}:${port}`,
        protocol: 'vmess',
        address,
        port,
        uuid,
        password: '',
        method: '',
        network,
        security,
        sni,
        host: hostHeader,
        path,
        fingerprint: str(obj.fp as string),
        flow: '',
        publicKey: '',
        shortId: '',
        allowInsecure: str(obj.allowInsecure as string) === '1',
        raw: link,
      },
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Could not parse the VMess link.' };
  }
}

/**
 * Parse a `trojan://` link.
 *
 * Shape: `trojan://password@host:port?security=tls&sni=…&type=ws&path=…#name`
 */
function parseTrojan(link: string): ParseResult {
  try {
    const withoutScheme = link.slice('trojan://'.length);
    const hashIndex = withoutScheme.indexOf('#');
    const name = hashIndex >= 0 ? safeDecode(withoutScheme.slice(hashIndex + 1)) : '';
    const body = hashIndex >= 0 ? withoutScheme.slice(0, hashIndex) : withoutScheme;

    const queryIndex = body.indexOf('?');
    const authority = queryIndex >= 0 ? body.slice(0, queryIndex) : body;
    const query = queryIndex >= 0 ? body.slice(queryIndex + 1) : '';

    const atIndex = authority.lastIndexOf('@');
    if (atIndex < 0) return { ok: false, error: 'A Trojan link needs a password@host:port.' };
    const password = safeDecode(authority.slice(0, atIndex));
    const { host, port } = splitHostPort(authority.slice(atIndex + 1));
    if (!host) return { ok: false, error: 'A Trojan link has no address.' };
    if (!password) return { ok: false, error: 'A Trojan link needs a password.' };
    if (!validPort(port)) return { ok: false, error: `The port ${port} is not a valid port.` };

    const params = new URLSearchParams(query);
    const network = normaliseNetwork(str(params.get('type')));
    // Trojan is TLS by definition unless the link explicitly says otherwise.
    const security = normaliseSecurity(str(params.get('security')) || 'tls');
    const sni = str(params.get('sni')) || str(params.get('peer')) || str(params.get('host'));

    return {
      ok: true,
      config: {
        id: makeId('trojan', host, port, password),
        name: name || `${host}:${port}`,
        protocol: 'trojan',
        address: host,
        port,
        uuid: '',
        password,
        method: '',
        network,
        security,
        sni,
        host: str(params.get('host')),
        path: str(params.get('path')) || str(params.get('serviceName')),
        fingerprint: str(params.get('fp')),
        flow: str(params.get('flow')),
        publicKey: str(params.get('pbk')),
        shortId: str(params.get('sid')),
        allowInsecure: str(params.get('allowInsecure')) === '1',
        raw: link,
      },
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Could not parse the Trojan link.' };
  }
}

/**
 * Parse a `ss://` link.
 *
 * Two shapes exist: `ss://base64(method:password)@host:port#name` (SIP002) and the older
 * `ss://base64(method:password@host:port)#name`. Both are handled.
 */
function parseShadowsocks(link: string): ParseResult {
  try {
    const withoutScheme = link.slice('ss://'.length);
    const hashIndex = withoutScheme.indexOf('#');
    const name = hashIndex >= 0 ? safeDecode(withoutScheme.slice(hashIndex + 1)) : '';
    let body = hashIndex >= 0 ? withoutScheme.slice(0, hashIndex) : withoutScheme;

    // Strip a query string (plugin options) — the core config here does not use plugins.
    const queryIndex = body.indexOf('?');
    if (queryIndex >= 0) body = body.slice(0, queryIndex);

    let method = '';
    let password = '';
    let host = '';
    let port = 8388;

    if (body.includes('@')) {
      // SIP002: the userinfo is base64(method:password).
      const atIndex = body.lastIndexOf('@');
      const userinfo = body.slice(0, atIndex);
      const decoded = base64Decode(userinfo) || safeDecode(userinfo);
      const colon = decoded.indexOf(':');
      method = colon >= 0 ? decoded.slice(0, colon) : decoded;
      password = colon >= 0 ? decoded.slice(colon + 1) : '';
      const parsed = splitHostPort(body.slice(atIndex + 1));
      host = parsed.host;
      port = parsed.port;
    } else {
      // Legacy: the whole body is base64(method:password@host:port).
      const decoded = base64Decode(body);
      if (!decoded) return { ok: false, error: 'The Shadowsocks link is not valid base64.' };
      const atIndex = decoded.lastIndexOf('@');
      if (atIndex < 0) return { ok: false, error: 'The Shadowsocks link has no address.' };
      const userinfo = decoded.slice(0, atIndex);
      const colon = userinfo.indexOf(':');
      method = colon >= 0 ? userinfo.slice(0, colon) : userinfo;
      password = colon >= 0 ? userinfo.slice(colon + 1) : '';
      const parsed = splitHostPort(decoded.slice(atIndex + 1));
      host = parsed.host;
      port = parsed.port;
    }

    if (!host) return { ok: false, error: 'The Shadowsocks link has no address.' };
    if (!validPort(port)) return { ok: false, error: `The port ${port} is not a valid port.` };

    return {
      ok: true,
      config: {
        id: makeId('shadowsocks', host, port, password),
        name: name || `${host}:${port}`,
        protocol: 'shadowsocks',
        address: host,
        port,
        uuid: '',
        password,
        method: method || 'aes-256-gcm',
        network: 'tcp',
        security: 'none',
        sni: '',
        host: '',
        path: '',
        fingerprint: '',
        flow: '',
        publicKey: '',
        shortId: '',
        allowInsecure: false,
        raw: link,
      },
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'Could not parse the Shadowsocks link.' };
  }
}

/** Split `host:port`, `[v6]:port` or a bare host. */
function splitHostPort(value: string): { host: string; port: number } {
  const trimmed = value.trim();
  if (trimmed.startsWith('[')) {
    const close = trimmed.indexOf(']');
    const host = trimmed.slice(1, close);
    const rest = trimmed.slice(close + 1).replace(/^:/, '');
    return { host, port: num(rest, 443) };
  }
  const colon = trimmed.lastIndexOf(':');
  if (colon < 0) return { host: trimmed, port: 443 };
  return { host: trimmed.slice(0, colon), port: num(trimmed.slice(colon + 1), 443) };
}

// ---------------------------------------------------------------------------------------
// Public parse entry points
// ---------------------------------------------------------------------------------------

/** Parse one share link of any supported protocol. */
export function parseLink(link: string): ParseResult {
  const trimmed = link.trim();
  if (!trimmed) return { ok: false, error: 'The link is empty.' };
  if (trimmed.startsWith('vless://')) return parseVless(trimmed);
  if (trimmed.startsWith('vmess://')) return parseVmess(trimmed);
  if (trimmed.startsWith('trojan://')) return parseTrojan(trimmed);
  if (trimmed.startsWith('ss://')) return parseShadowsocks(trimmed);
  return { ok: false, error: 'Only vless://, vmess://, trojan:// and ss:// links are supported.' };
}

/**
 * Parse a raw Xray JSON config.
 *
 * Only the first outbound that is a real proxy is read — the rest of a full config
 * (routing, inbounds, DNS) is replaced by the app's own, because the app owns the TUN and
 * the SOCKS inbound. This is a deliberate simplification: it means a pasted config always
 * behaves the same way as a link, instead of two different code paths.
 */
export function parseJsonConfig(text: string): ParseResult {
  try {
    const obj = JSON.parse(text) as {
      outbounds?: {
        protocol?: string;
        settings?: Record<string, unknown>;
        streamSettings?: Record<string, unknown>;
      }[];
    };
    const outbound = obj.outbounds?.find((o) =>
      ['vless', 'vmess', 'trojan', 'shadowsocks'].includes(String(o.protocol)),
    );
    if (!outbound) {
      return { ok: false, error: 'The JSON has no vless/vmess/trojan/shadowsocks outbound.' };
    }
    const protocol = String(outbound.protocol) as Protocol;
    const settings = outbound.settings ?? {};
    const stream = (outbound.streamSettings ?? {}) as Record<string, unknown>;

    // Each protocol keeps its server list under a different key.
    const servers = (settings.vnext ?? settings.servers ?? []) as Record<string, unknown>[];
    const server = servers[0] ?? {};
    const address = str(server.address as string);
    const port = num(server.port as string, 443);
    if (!address) return { ok: false, error: 'The JSON outbound has no address.' };

    const users = (server.users ?? []) as Record<string, unknown>[];
    const user = users[0] ?? {};
    const uuid = str(user.id as string);
    const password = str((server.password as string) ?? (user.password as string));
    const method = str(server.method as string);

    const network = normaliseNetwork(str(stream.network as string));
    const security = normaliseSecurity(str(stream.security as string));
    const tlsSettings = (stream.tlsSettings ?? stream.realitySettings ?? {}) as Record<string, unknown>;
    const wsSettings = (stream.wsSettings ?? {}) as Record<string, unknown>;
    const grpcSettings = (stream.grpcSettings ?? {}) as Record<string, unknown>;
    const xhttpSettings = (stream.xhttpSettings ?? {}) as Record<string, unknown>;

    const sni = str(tlsSettings.serverName as string);
    const hostHeader = str((wsSettings.headers as Record<string, string>)?.Host as string);
    const path =
      str(wsSettings.path as string) ||
      str(grpcSettings.serviceName as string) ||
      str(xhttpSettings.path as string);

    return {
      ok: true,
      config: {
        id: makeId(protocol, address, port, uuid || password),
        name: `${address}:${port}`,
        protocol,
        address,
        port,
        uuid,
        password,
        method,
        network,
        security,
        sni,
        host: hostHeader,
        path,
        fingerprint: str(tlsSettings.fingerprint as string),
        flow: str(user.flow as string),
        publicKey: str(tlsSettings.publicKey as string),
        shortId: str(tlsSettings.shortId as string),
        allowInsecure: Boolean(tlsSettings.allowInsecure),
        raw: text,
      },
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : 'The JSON could not be parsed.' };
  }
}

/**
 * Parse a subscription body.
 *
 * A subscription is either a base64 blob of links (the common case) or plain links, one
 * per line. Both are accepted, and every line is parsed independently so one bad entry
 * does not discard the rest.
 */
export function parseSubscription(body: string): { configs: ServerConfig[]; errors: string[] } {
  const trimmed = body.trim();
  const decoded = trimmed.includes('://') ? trimmed : base64Decode(trimmed);
  const text = decoded || trimmed;

  const configs: ServerConfig[] = [];
  const errors: string[] = [];
  for (const line of text.split(/\r?\n/)) {
    const entry = line.trim();
    if (!entry) continue;
    if (!entry.includes('://')) continue;
    const result = parseLink(entry);
    if (result.ok) configs.push(result.config);
    else errors.push(result.error);
  }
  return { configs, errors };
}

/** Parse whatever the user pasted: a link, a JSON config, or a subscription blob. */
export function parseAny(text: string): { configs: ServerConfig[]; errors: string[] } {
  const trimmed = text.trim();
  if (!trimmed) return { configs: [], errors: ['Nothing was pasted.'] };

  if (trimmed.startsWith('{')) {
    const result = parseJsonConfig(trimmed);
    return result.ok ? { configs: [result.config], errors: [] } : { configs: [], errors: [result.error] };
  }
  if (trimmed.includes('://')) {
    // Could be one link or many lines of them.
    const lines = trimmed.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (lines.length === 1) {
      const result = parseLink(lines[0]);
      return result.ok ? { configs: [result.config], errors: [] } : { configs: [], errors: [result.error] };
    }
    return parseSubscription(trimmed);
  }
  return parseSubscription(trimmed);
}

// ---------------------------------------------------------------------------------------
// Xray JSON generation
// ---------------------------------------------------------------------------------------

/** The local SOCKS port the core listens on. Must match `HevTunnel.SOCKS_PORT`. */
export const SOCKS_PORT = 1080;

/** True when a string is a literal IPv4 or IPv6 address rather than a hostname. */
export function isIpLiteral(value: string): boolean {
  const v = value.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(v)) return true;
  // A bare IPv6 address contains a colon and no scheme.
  return v.includes(':') && /^[0-9a-fA-F:.]+$/.test(v);
}

/**
 * Build the `streamSettings` block for a config.
 *
 * This is where the transport and the security layer are expressed, and it is the part
 * that most often goes wrong in hand-written configs: a WebSocket config without a `Host`
 * header, or a REALITY config without `publicKey`, connects to nothing. Each field is
 * only emitted when the user's config actually supplied it.
 */
function buildStreamSettings(config: ServerConfig): Record<string, unknown> {
  const stream: Record<string, unknown> = { network: config.network };

  if (config.security === 'tls') {
    stream.security = 'tls';
    stream.tlsSettings = {
      serverName: config.sni || config.address,
      allowInsecure: config.allowInsecure,
      ...(config.fingerprint ? { fingerprint: config.fingerprint } : {}),
    };
  } else if (config.security === 'reality') {
    stream.security = 'reality';
    stream.realitySettings = {
      serverName: config.sni || config.host || config.address,
      fingerprint: config.fingerprint || 'chrome',
      publicKey: config.publicKey,
      shortId: config.shortId,
      ...(config.flow ? { flow: config.flow } : {}),
    };
  }

  if (config.network === 'ws') {
    stream.wsSettings = {
      path: config.path || '/',
      ...(config.host ? { headers: { Host: config.host } } : {}),
    };
  } else if (config.network === 'grpc') {
    stream.grpcSettings = {
      serviceName: config.path || '',
      multiMode: false,
    };
  } else if (config.network === 'xhttp') {
    stream.xhttpSettings = {
      path: config.path || '/',
      ...(config.host ? { host: config.host } : {}),
    };
  } else if (config.network === 'httpupgrade') {
    stream.httpupgradeSettings = {
      path: config.path || '/',
      ...(config.host ? { host: config.host } : {}),
    };
  }

  return stream;
}

/** Build the protocol-specific `settings` block. */
function buildOutboundSettings(config: ServerConfig): Record<string, unknown> {
  if (config.protocol === 'vless') {
    return {
      vnext: [
        {
          address: config.address,
          port: config.port,
          users: [
            {
              id: config.uuid,
              encryption: 'none',
              ...(config.flow ? { flow: config.flow } : {}),
            },
          ],
        },
      ],
    };
  }
  if (config.protocol === 'vmess') {
    return {
      vnext: [
        {
          address: config.address,
          port: config.port,
          users: [
            {
              id: config.uuid,
              alterId: 0,
              security: 'auto',
            },
          ],
        },
      ],
    };
  }
  if (config.protocol === 'trojan') {
    return {
      servers: [
        {
          address: config.address,
          port: config.port,
          password: config.password,
        },
      ],
    };
  }
  // Shadowsocks
  return {
    servers: [
      {
        address: config.address,
        port: config.port,
        method: config.method || 'aes-256-gcm',
        password: config.password,
      },
    ],
  };
}

/**
 * Build a complete Xray-core JSON config for one server.
 *
 * The shape is fixed: one SOCKS inbound on loopback (which the TUN bridge feeds), one
 * proxy outbound, and a `freedom` outbound for direct traffic. `domainStrategy` is
 * `AsIs` so the server resolves names itself — the same behaviour a desktop client has,
 * and the reason a config that works elsewhere works here.
 */
export function buildXrayConfig(config: ServerConfig): string {
  const json = {
    log: { loglevel: 'warning' },
    inbounds: [
      {
        tag: 'socks-in',
        listen: '127.0.0.1',
        port: SOCKS_PORT,
        protocol: 'socks',
        settings: { auth: 'noauth', udp: true, ip: '127.0.0.1' },
        sniffing: { enabled: true, destOverride: ['http', 'tls', 'quic'] },
      },
    ],
    outbounds: [
      {
        tag: 'proxy',
        protocol: config.protocol,
        settings: buildOutboundSettings(config),
        streamSettings: buildStreamSettings(config),
      },
      { tag: 'direct', protocol: 'freedom', settings: { domainStrategy: 'AsIs' } },
    ],
    routing: {
      domainStrategy: 'AsIs',
      rules: [
        // The proxy server itself must be reached directly, or the tunnel would loop.
        //
        // The field differs by what the address is: Xray matches a literal address with
        // `ip`, and a hostname with `domain`. Putting an IP in `domain` silently matches
        // nothing, which would let the connection to the server itself be routed back
        // into the proxy — a loop that looks like "the tunnel connects but nothing loads".
        isIpLiteral(config.address)
          ? { type: 'field', outboundTag: 'direct', ip: [config.address] }
          : { type: 'field', outboundTag: 'direct', domain: [`full:${config.address}`] },
      ],
    },
  };
  return JSON.stringify(json);
}

/**
 * A one-line summary for a list row: protocol, transport and security.
 *
 * The address is deliberately not included — the app masks endpoints everywhere else, and
 * a list row is the most likely thing to be screenshotted.
 */
export function describeConfig(config: ServerConfig): string {
  const parts = [config.protocol.toUpperCase()];
  if (config.network !== 'tcp') parts.push(config.network.toUpperCase());
  if (config.security !== 'none') parts.push(config.security.toUpperCase());
  return parts.join(' · ');
}

/**
 * Return a copy of a config with **only** its address replaced.
 *
 * This is the scanner-to-connection bridge, and the restriction is the point: when the
 * scanner finds an address that answers, the user can test their own server through that
 * address — but the port, the SNI, the UUID, the transport and every other parameter stay
 * exactly as the user's config had them. Changing any of those would silently turn a
 * working config into a different one, which is how a "fix" breaks a server.
 *
 * The id is left unchanged too, so the override is a test of the same server, not a new
 * entry in the list.
 */
export function withAddressOverride(config: ServerConfig, address: string): ServerConfig {
  return { ...config, address: address.trim() };
}
