/**
 * Bilingual dictionary (English / Persian). Every user-visible string in the app comes
 * from here, so switching the language in the Settings tab changes the whole app at once.
 */
export type Lang = 'en' | 'fa';

export const strings = {
  en: {
    appName: 'KING VPN',
    tagline: 'Fast, private, effortless.',

    // Tabs
    tabHome: 'Home',
    tabSettings: 'Settings',
    tabThird: 'Panel',

    // Home
    fastestCountry: 'Fastest country',
    fastestCountryHint: 'One tap — the panel picks the best server for you',
    groups: 'Server groups',
    groupsHint: 'Pick a group to connect through',
    groupTrojan: 'Trojan',
    groupVless: 'VLESS',
    groupVmess: 'VMess',
    groupVlessHu: 'VLESS HU',
    connecting: 'Connecting…',
    connected: 'Connected',
    disconnected: 'Disconnected',
    disconnect: 'Disconnect',
    tapToConnect: 'Tap to connect',
    secureSession: 'Secure session active',
    activeServer: 'Active server',
    noServers: 'No servers yet',
    noServersHint: 'Pull down to refresh, or check the panel.',
    refresh: 'Refresh',
    loading: 'Loading…',
    errorTitle: 'Something went wrong',
    tunnelUnavailable:
      'This build has no native VPN module. Install a development or release APK — Expo Go cannot create a VPN.',
    vpnPermissionNeeded: 'Tap to allow the VPN connection',
    received: 'Received',
    sent: 'Sent',
    handshake: 'Handshake',
    handshakeOk: 'OK',
    handshakePending: 'Pending',

    // Servers page
    serversTitle: 'Servers',
    serversSubtitle: 'Every server the panel publishes, grouped by protocol',
    serverCount: '{n} servers',
    connect: 'Connect',
    selected: 'Active',
    brokenTitle: 'Unreadable entries',
    brokenHint: 'The panel sent these, but they could not be parsed',

    // Settings
    settingsTitle: 'Settings',
    settingsSubtitle: 'Panel, channel, owner and appearance',
    channel: 'Channel',
    channelHint: 'Updates, configs and announcements',
    owner: 'Owner',
    ownerHint: 'Questions, feedback and support',
    preferences: 'Preferences',
    language: 'Language',
    theme: 'Theme',
    dark: 'Black',
    light: 'White',
    account: 'Panel connection',
    token: 'Panel token',
    tokenHint: 'Your own token, stored on this device only',
    tokenMissing: 'No token yet',
    tokenPage: 'Open the token page on the panel',
    tokenPageHint: 'Create a token on your panel',
    version: 'Version',
    open: 'Open',
    tapToOpen: 'Tap to open',
    copy: 'Copy',
    copied: 'Copied',

    // Panel setup
    setupTitle: 'Connect your panel',
    setupSubtitle:
      'Enter the address of your panel and the token it gave you. Both stay on this phone — you can change them any time in Settings.',
    panelUrl: 'Panel address',
    panelUrlPlaceholder: 'https://panel.example.com',
    panelUrlHint: 'The domain your panel runs on. https:// is added if you leave it out.',
    panelToken: 'Token',
    panelTokenPlaceholder: 'Paste the token from your panel',
    panelTokenHint: 'Create one on your panel’s /token page.',
    testAndSave: 'Test and save',
    testing: 'Checking…',
    saveAnyway: 'Save without testing',
    setupNote:
      'The app has no built-in address: every user enters their own. Nothing is sent anywhere except to the panel you type here.',
    setupErrorUrl: 'That does not look like a web address. Example: https://panel.example.com',
    setupErrorToken: 'The token is too short. Paste the whole token.',
    setupErrorReach: 'Could not reach the panel.',
    panelAddress: 'Address',
    editPanel: 'Change address and token',
    notConfigured: 'No panel set',
    notConfiguredHint: 'Enter your panel address and token to load the servers.',
    openSetup: 'Set up the panel',
    clearPanel: 'Forget this panel',
    clearPanelTitle: 'Forget the panel?',
    clearPanelMessage:
      'The address and token are removed from this phone and you will be asked for them again. Your servers on the panel are not touched.',
    cancel: 'Cancel',
    forget: 'Forget',
  },
  fa: {
    appName: 'KING VPN',
    tagline: 'سریع، خصوصی، ساده.',

    // Tabs
    tabHome: 'خانه',
    tabSettings: 'تنظیمات',
    tabThird: 'پنل',

    // Home
    fastestCountry: 'سریع‌ترین کشور',
    fastestCountryHint: 'با یک لمس — پنل بهترین سرور را برایتان انتخاب می‌کند',
    groups: 'گروه‌های سرور',
    groupsHint: 'یک گروه را برای اتصال انتخاب کنید',
    groupTrojan: 'تورجان',
    groupVless: 'ویلس',
    groupVmess: 'ویمس',
    groupVlessHu: 'ویلس HU',
    connecting: 'در حال اتصال…',
    connected: 'متصل',
    disconnected: 'قطع',
    disconnect: 'قطع اتصال',
    tapToConnect: 'برای اتصال بزنید',
    secureSession: 'نشست امن فعال است',
    activeServer: 'سرور فعال',
    noServers: 'هنوز سروری نیست',
    noServersHint: 'برای به‌روزرسانی پایین بکشید یا پنل را بررسی کنید.',
    refresh: 'به‌روزرسانی',
    loading: 'در حال بارگذاری…',
    errorTitle: 'مشکلی پیش آمد',
    tunnelUnavailable:
      'این نسخه ماژول بومی VPN ندارد. نسخه‌ی توسعه یا APK نهایی را نصب کنید — Expo Go نمی‌تواند VPN بسازد.',
    vpnPermissionNeeded: 'برای اجازه‌ی اتصال VPN بزنید',
    received: 'دریافت',
    sent: 'ارسال',
    handshake: 'دست‌دهی',
    handshakeOk: 'برقرار',
    handshakePending: 'در انتظار',

    // Servers page
    serversTitle: 'سرورها',
    serversSubtitle: 'همه‌ی سرورهایی که پنل منتشر می‌کند، گروه‌بندی‌شده بر اساس پروتکل',
    serverCount: '{n} سرور',
    connect: 'اتصال',
    selected: 'فعال',
    brokenTitle: 'موارد ناخوانا',
    brokenHint: 'پنل این‌ها را فرستاد، اما قابل خواندن نبودند',

    // Settings
    settingsTitle: 'تنظیمات',
    settingsSubtitle: 'پنل، کانال، مالک و ظاهر',
    channel: 'کانال',
    channelHint: 'به‌روزرسانی‌ها، کانفیگ‌ها و اطلاعیه‌ها',
    owner: 'مالک',
    ownerHint: 'پرسش، بازخورد و پشتیبانی',
    preferences: 'تنظیمات',
    language: 'زبان',
    theme: 'تم',
    dark: 'سیاه',
    light: 'سفید',
    account: 'اتصال به پنل',
    token: 'توکن پنل',
    tokenHint: 'توکن خودتان — فقط روی همین دستگاه ذخیره می‌شود',
    tokenMissing: 'هنوز توکنی نیست',
    tokenPage: 'باز کردن صفحه‌ی توکن در پنل',
    tokenPageHint: 'ساخت توکن روی پنل خودتان',
    version: 'ورژن',
    open: 'بازکردن',
    tapToOpen: 'برای بازکردن بزنید',
    copy: 'کپی',
    copied: 'کپی شد',

    // Panel setup
    setupTitle: 'اتصال به پنل خودتان',
    setupSubtitle:
      'آدرس پنل و توکنی که دریافت کرده‌اید را وارد کنید. هر دو روی همین گوشی می‌مانند و هر وقت خواستید در تنظیمات تغییرشان دهید.',
    panelUrl: 'آدرس پنل',
    panelUrlPlaceholder: 'https://panel.example.com',
    panelUrlHint: 'دامنه‌ای که پنل روی آن اجرا می‌شود. اگر https:// ننویسید، خودکار اضافه می‌شود.',
    panelToken: 'توکن',
    panelTokenPlaceholder: 'توکن پنل خودتان را اینجا بچسبانید',
    panelTokenHint: 'روی صفحه‌ی /token پنل خودتان یکی بسازید.',
    testAndSave: 'تست و ذخیره',
    testing: 'در حال بررسی…',
    saveAnyway: 'ذخیره بدون تست',
    setupNote:
      'اپ هیچ آدرسی را از پیش ندارد: هر کاربر آدرس خودش را وارد می‌کند. هیچ داده‌ای جز به پنلی که اینجا می‌نویسید ارسال نمی‌شود.',
    setupErrorUrl: 'این شبیه آدرس وب نیست. مثال: https://panel.example.com',
    setupErrorToken: 'توکن خیلی کوتاه است. تمام توکن را بچسبانید.',
    setupErrorReach: 'به پنل دسترسی نداشتیم.',
    panelAddress: 'آدرس',
    editPanel: 'تغییر آدرس و توکن',
    notConfigured: 'پنلی تنظیم نشده',
    notConfiguredHint: 'برای دریافت سرورها، آدرس پنل و توکن خودتان را وارد کنید.',
    openSetup: 'تنظیم پنل',
    clearPanel: 'پاک کردن پنل',
    clearPanelTitle: 'پنل پاک شود؟',
    clearPanelMessage:
      'آدرس و توکن از این گوشی پاک می‌شوند و دوباره از شما پرسیده می‌شود. سرورهای شما روی پنل دست نمی‌خورد.',
    cancel: 'لغو',
    forget: 'پاک کردن',
  },
} as const;

export type StringKey = keyof typeof strings.en;

export function translate(lang: Lang, key: StringKey): string {
  return strings[lang][key] ?? strings.en[key];
}
