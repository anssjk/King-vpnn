import Ionicons from '@expo/vector-icons/Ionicons';
import { LinearGradient } from 'expo-linear-gradient';
import type { ComponentProps } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { elevation, radius, spacing, useColors } from '@/constants/theme';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';

type Props = {
  title: string;
  onPress: () => void;
  variant?: Variant;
  icon?: ComponentProps<typeof Ionicons>['name'];
  loading?: boolean;
  disabled?: boolean;
};

/**
 * The app's button. `primary` and `danger` are filled with the brand gradient; the other
 * variants are frosted glass. Every variant keeps the same height and radius so rows of
 * buttons line up.
 */
export function Button({ title, onPress, variant = 'primary', icon, loading, disabled }: Props) {
  const colors = useColors();
  const inactive = disabled || loading;
  const filled = variant === 'primary' || variant === 'danger';
  const foreground = filled ? colors.onPrimary : colors.primary;

  const content = loading ? (
    <ActivityIndicator color={foreground} />
  ) : (
    <View style={styles.row}>
      {icon ? <Ionicons name={icon} size={18} color={foreground} /> : null}
      <Text style={[styles.title, { color: foreground }]}>{title}</Text>
    </View>
  );

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!inactive, busy: !!loading }}
      disabled={inactive}
      onPress={onPress}
      hitSlop={6}
      style={({ pressed }) => [
        styles.base,
        filled ? elevation.soft : null,
        {
          backgroundColor: filled ? 'transparent' : variant === 'ghost' ? 'transparent' : colors.card,
          borderColor: filled || variant === 'ghost' ? 'transparent' : colors.border,
        },
        pressed && { opacity: 0.85, transform: [{ scale: 0.985 }] },
        inactive && { opacity: 0.5 },
      ]}>
      {filled ? (
        <LinearGradient
          colors={variant === 'danger' ? ([colors.danger, '#B3261E'] as const) : colors.gradientBrand}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.fill}>
          {content}
        </LinearGradient>
      ) : (
        content
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    minHeight: 52,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  title: { fontSize: 16, fontWeight: '700', letterSpacing: 0.2 },
});
