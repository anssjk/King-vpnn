import { Image } from 'expo-image';
import { StyleSheet, Text, View } from 'react-native';

import { useColors } from '@/constants/theme';

type Props = {
  size?: number;
  /** Show the wordmark next to the icon. */
  withWordmark?: boolean;
};

/**
 * The KING VPN app icon (the crowned lion) plus the wordmark.
 *
 * The same artwork that ships as the launcher icon is used here, so the logo inside the app
 * and the icon on the home screen are always the same picture.
 */
export function BrandMark({ size = 44, withWordmark }: Props) {
  const colors = useColors();
  return (
    <View style={styles.row}>
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size * 0.31,
          shadowColor: colors.primary,
          shadowOpacity: 0.5,
          shadowRadius: size * 0.35,
          shadowOffset: { width: 0, height: size * 0.16 },
          elevation: 8,
        }}>
        <Image
          source={require('../../../assets/images/icon.png')}
          style={[styles.tile, { width: size, height: size, borderRadius: size * 0.31 }]}
          contentFit="cover"
          transition={150}
          accessibilityIgnoresInvertColors
        />
      </View>
      {withWordmark ? (
        <Text style={[styles.wordmark, { color: colors.text, fontSize: size * 0.6 }]}>
          KING <Text style={{ color: colors.primary }}>VPN</Text>
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  tile: { backgroundColor: '#05070F' },
  wordmark: { fontWeight: '900', letterSpacing: -0.6 },
});
