import type { ReactNode } from 'react';
import {
  ScrollView,
  StyleSheet,
  View,
  type ScrollViewProps,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AuroraBackground } from '@/components/aurora-background';
import { spacing } from '@/constants/theme';

type Props = {
  children: ReactNode;
  scroll?: boolean;
  /** Extra padding at the bottom so content clears a floated tab bar. */
  bottomInset?: number;
  contentStyle?: StyleProp<ViewStyle>;
  /** Extra props for the ScrollView, e.g. a RefreshControl. */
  scrollProps?: ScrollViewProps;
};

/**
 * Page container: safe-area aware, paints the aurora backdrop, and optionally scrolls.
 * Screens never set their own background — they get the app's signature gradient here.
 */
export function Screen({ children, scroll = true, bottomInset = 0, contentStyle, scrollProps }: Props) {
  const body = scroll ? (
    <ScrollView
      {...scrollProps}
      contentContainerStyle={[styles.content, { paddingBottom: spacing.lg + bottomInset }, contentStyle]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}>
      {children}
    </ScrollView>
  ) : (
    <View style={[styles.root, contentStyle]}>{children}</View>
  );

  return (
    <SafeAreaView edges={['top', 'left', 'right']} style={styles.root}>
      <AuroraBackground />
      {body}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { padding: spacing.md, gap: spacing.md },
});
