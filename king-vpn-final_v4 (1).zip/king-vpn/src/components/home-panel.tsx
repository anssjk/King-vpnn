import Ionicons from '@expo/vector-icons/Ionicons';
import Constants from 'expo-constants';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { BrandMark, Card, SectionHeader } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { useApp } from '@/lib/app-context';
import { SERVER_GROUPS, type ServerGroup } from '@/lib/api';
import { tapFeedback } from '@/lib/haptics';
import { useSettings } from '@/lib/settings-context';

const VERSION = Constants.expoConfig?.version ?? '1.0.0';

const GROUP_META: Record<ServerGroup, { icon: keyof typeof Ionicons.glyphMap; colors: readonly [string, string] }> = {
  trojan: { icon: 'shield-half', colors: ['#F6821F', '#E8590C'] },
  vless: { icon: 'flash', colors: ['#0A84FF', '#4DA3FF'] },
  vmess: { icon: 'layers', colors: ['#7C4DFF', '#A78BFA'] },
  'vless-hu': { icon: 'globe', colors: ['#00D6D6', '#12B76A'] },
};

/**
 * Home: exactly two things.
 *
 *   1. One big "Fastest country" button — the panel decides which server is best.
 *   2. One row of group buttons (Trojan / VLESS / VMess / VLESS HU) that connect through
 *      the fastest server of that group.
 *
 * There is no token field, no WARP picker and no scanner here: the token is issued by the
 * panel and the servers come from it.
 */
export function HomePanel() {
  const colors = useColors();
  const router = useRouter();
  const { t, rtl } = useSettings();
  const {
    status,
    connectFastest,
    disconnect,
    error,
    activeName,
    servers,
    serversLoading,
    serversError,
    refreshServers,
    panelConfigured,
    canTunnel,
    tunnelUnavailableReason,
    vpnGranted,
    requestVpn,
    tunnel,
  } = useApp();

  const [busyGroup, setBusyGroup] = useState<ServerGroup | 'fastest' | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const connected = status === 'connected';
  const connecting = status === 'connecting';

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refreshServers();
    setRefreshing(false);
  }, [refreshServers]);

  const onFastest = async () => {
    tapFeedback();
    if (connected) {
      await disconnect();
      return;
    }
    setBusyGroup('fastest');
    await connectFastest(null);
    setBusyGroup(null);
  };

  const onGroup = async (group: ServerGroup) => {
    tapFeedback();
    if (connected) {
      await disconnect();
      return;
    }
    setBusyGroup(group);
    await connectFastest(group);
    setBusyGroup(null);
  };

  const statusLabel = connecting ? t('connecting') : connected ? t('connected') : t('disconnected');
  const handshake = (tunnel?.latestHandshakeMs ?? 0) > 0;

  return (
    <Screen
      bottomInset={96}
      contentStyle={{ gap: spacing.md }}
      scrollProps={{
        refreshControl: (
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        ),
      }}>
      {/* Header */}
      <View style={[styles.header, rtl && styles.rowReverse]}>
        <BrandMark size={40} withWordmark />
        <View style={[styles.versionPill, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View
            style={[
              styles.dot,
              { backgroundColor: connected ? colors.success : connecting ? colors.warning : colors.faint },
            ]}
          />
          <Text style={[styles.versionText, { color: colors.muted }]}>{VERSION}</Text>
        </View>
      </View>

      {/* Status line */}
      <View style={[styles.statusRow, rtl && styles.rowReverse]}>
        <Text style={[styles.statusText, { color: connected ? colors.success : colors.text }]}>
          {statusLabel}
        </Text>
        {connected && activeName ? (
          <Text style={[styles.activeName, { color: colors.muted }]} numberOfLines={1}>
            {activeName}
          </Text>
        ) : null}
      </View>

      {/* 1. The one big button */}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={t('fastestCountry')}
        disabled={connecting || busyGroup !== null}
        onPress={onFastest}
        style={({ pressed }) => [styles.heroPress, pressed && { transform: [{ scale: 0.985 }] }]}>
        <LinearGradient
          colors={connected ? colors.gradientSuccess : colors.gradientConnect}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.9, y: 1 }}
          style={styles.hero}>
          <LinearGradient
            colors={['rgba(255,255,255,0.35)', 'rgba(255,255,255,0)']}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={styles.heroGloss}
          />
          <View style={styles.heroInner}>
            {busyGroup === 'fastest' || connecting ? (
              <ActivityIndicator size="large" color="#FFFFFF" />
            ) : (
              <Ionicons name={connected ? 'power' : 'flash'} size={44} color="#FFFFFF" />
            )}
            <Text style={styles.heroTitle}>
              {connected ? t('disconnect') : t('fastestCountry')}
            </Text>
            <Text style={styles.heroHint}>
              {connected ? t('secureSession') : t('fastestCountryHint')}
            </Text>
          </View>
        </LinearGradient>
      </Pressable>

      {/* 2. The group buttons */}
      <View style={styles.section}>
        <SectionHeader title={t('groups')} subtitle={t('groupsHint')} />
        <View style={styles.groupGrid}>
          {SERVER_GROUPS.map((group) => {
            const meta = GROUP_META[group];
            const count = servers.filter((s) => s.remote.group === group).length;
            const busy = busyGroup === group;
            const label =
              group === 'trojan'
                ? t('groupTrojan')
                : group === 'vless'
                  ? t('groupVless')
                  : group === 'vmess'
                    ? t('groupVmess')
                    : t('groupVlessHu');
            return (
              <Pressable
                key={group}
                accessibilityRole="button"
                accessibilityLabel={label}
                disabled={connecting || busyGroup !== null}
                onPress={() => onGroup(group)}
                style={({ pressed }) => [
                  styles.groupBtn,
                  { backgroundColor: colors.card, borderColor: colors.border },
                  pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                  (connecting || busyGroup !== null) && !busy && { opacity: 0.55 },
                ]}>
                <LinearGradient
                  colors={meta.colors}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.groupIcon}>
                  {busy ? (
                    <ActivityIndicator size="small" color="#FFFFFF" />
                  ) : (
                    <Ionicons name={meta.icon} size={20} color="#FFFFFF" />
                  )}
                </LinearGradient>
                <Text style={[styles.groupLabel, { color: colors.text }]} numberOfLines={1}>
                  {label}
                </Text>
                <Text style={[styles.groupCount, { color: colors.faint }]}>
                  {serversLoading ? t('loading') : `${count}`}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      {/* Notices */}
      {!canTunnel ? (
        <View style={[styles.noticeBox, { backgroundColor: colors.card, borderColor: colors.warning }]}>
          <Ionicons name="information-circle" size={18} color={colors.warning} />
          <Text style={[styles.noticeText, { color: colors.muted }]}>
            {tunnelUnavailableReason ?? t('tunnelUnavailable')}
          </Text>
        </View>
      ) : null}

      {canTunnel && !vpnGranted ? (
        <Pressable
          onPress={() => {
            tapFeedback();
            void requestVpn();
          }}
          style={({ pressed }) => [
            styles.noticeBox,
            { backgroundColor: colors.card, borderColor: colors.primary },
            pressed && { opacity: 0.85 },
          ]}>
          <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
          <Text style={[styles.noticeText, { color: colors.text }]}>{t('vpnPermissionNeeded')}</Text>
          <Ionicons name={rtl ? 'chevron-back' : 'chevron-forward'} size={16} color={colors.primary} />
        </Pressable>
      ) : null}

      {connected ? (
        <View style={[styles.trafficRow, rtl && styles.rowReverse]}>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="arrow-down" size={14} color={colors.success} />
            <Text style={[styles.trafficValue, { color: colors.text }]}>
              {formatBytes(tunnel?.rxBytes ?? 0)}
            </Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('received')}</Text>
          </View>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons name="arrow-up" size={14} color={colors.primary} />
            <Text style={[styles.trafficValue, { color: colors.text }]}>
              {formatBytes(tunnel?.txBytes ?? 0)}
            </Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('sent')}</Text>
          </View>
          <View style={[styles.trafficCell, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Ionicons
              name={handshake ? 'checkmark-circle' : 'time-outline'}
              size={14}
              color={handshake ? colors.success : colors.warning}
            />
            <Text style={[styles.trafficValue, { color: colors.text }]}>
              {handshake ? t('handshakeOk') : t('handshakePending')}
            </Text>
            <Text style={[styles.trafficLabel, { color: colors.faint }]}>{t('handshake')}</Text>
          </View>
        </View>
      ) : null}

      {!panelConfigured ? (
        <Card>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>{t('notConfigured')}</Text>
          <Text style={[styles.emptyHint, { color: colors.muted }]}>{t('notConfiguredHint')}</Text>
          <Pressable
            onPress={() => {
              tapFeedback();
              router.push({ pathname: '/setup', params: { edit: '1' } });
            }}
            style={({ pressed }) => [
              styles.refreshBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="settings-outline" size={15} color={colors.primary} />
            <Text style={[styles.refreshText, { color: colors.primary }]}>{t('openSetup')}</Text>
          </Pressable>
        </Card>
      ) : null}

      {panelConfigured && servers.length === 0 && !serversLoading ? (
        <Card>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>{t('noServers')}</Text>
          <Text style={[styles.emptyHint, { color: colors.muted }]}>{t('noServersHint')}</Text>
          <Pressable
            onPress={() => {
              tapFeedback();
              void onRefresh();
            }}
            style={({ pressed }) => [
              styles.refreshBtn,
              { backgroundColor: colors.cardAlt, borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}>
            <Ionicons name="refresh" size={15} color={colors.primary} />
            <Text style={[styles.refreshText, { color: colors.primary }]}>{t('refresh')}</Text>
          </Pressable>
        </Card>
      ) : null}

      {serversError || error ? (
        <View style={[styles.errorBox, { backgroundColor: colors.card, borderColor: colors.danger }]}>
          <Ionicons name="alert-circle" size={18} color={colors.danger} />
          <Text style={[styles.errorText, { color: colors.danger }]}>{error ?? serversError}</Text>
        </View>
      ) : null}
    </Screen>
  );
}

function formatBytes(bytes: number): string {
  if (!bytes || bytes < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value < 10 && unit > 0 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`;
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowReverse: { flexDirection: 'row-reverse' },
  versionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  dot: { width: 6, height: 6, borderRadius: 3 },
  versionText: { fontSize: 12, fontWeight: '700', letterSpacing: 0.3 },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
  statusText: { fontSize: 15, fontWeight: '800' },
  activeName: { fontSize: 12.5, flex: 1, textAlign: 'right' },
  heroPress: { borderRadius: radius.xl },
  hero: {
    borderRadius: radius.xl,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 12 },
    elevation: 14,
  },
  heroGloss: { position: 'absolute', top: 0, left: 0, right: 0, height: 90 },
  heroInner: { alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 40, paddingHorizontal: spacing.lg },
  heroTitle: { fontSize: 24, fontWeight: '900', color: '#FFFFFF', letterSpacing: -0.4, textAlign: 'center' },
  heroHint: { fontSize: 13, color: 'rgba(255,255,255,0.9)', textAlign: 'center' },
  section: { gap: spacing.sm },
  groupGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  groupBtn: {
    flexBasis: '48%',
    flexGrow: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.lg,
    padding: spacing.sm + 2,
  },
  groupIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  groupLabel: { flex: 1, fontSize: 14, fontWeight: '800' },
  groupCount: { fontSize: 11.5, fontWeight: '700' },
  noticeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 11,
  },
  noticeText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
  trafficRow: { flexDirection: 'row', gap: spacing.sm },
  trafficCell: {
    flex: 1,
    alignItems: 'center',
    gap: 2,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    paddingVertical: 10,
  },
  trafficValue: { fontSize: 13, fontWeight: '800' },
  trafficLabel: { fontSize: 9.5, fontWeight: '700', letterSpacing: 0.4, textTransform: 'uppercase' },
  emptyTitle: { fontSize: 15, fontWeight: '800' },
  emptyHint: { fontSize: 12.5, lineHeight: 18 },
  refreshBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.pill,
    paddingVertical: 9,
    marginTop: 4,
  },
  refreshText: { fontSize: 13, fontWeight: '800' },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },
});
