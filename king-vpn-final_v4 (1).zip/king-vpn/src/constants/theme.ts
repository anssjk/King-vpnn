import { useSettings } from '@/lib/settings-context';

/**
 * Design tokens for KING VPN.
 *
 * The look is a deep "aurora" gradient background with frosted glass surfaces floating on
 * top, a vivid cyan -> blue -> violet accent gradient, and a large glowing connect orb.
 * Every colour lives here so the light and dark themes stay in step and no screen
 * hard-codes a value.
 */
export type Gradient = readonly [string, string, ...string[]];

export type Palette = {
  // Accents
  primary: string;
  primaryDark: string;
  accent: string;
  onPrimary: string;
  // Surfaces
  background: string;
  backgroundAlt: string;
  card: string;
  cardSolid: string;
  cardAlt: string;
  border: string;
  borderStrong: string;
  // Text
  text: string;
  muted: string;
  faint: string;
  // States
  danger: string;
  success: string;
  warning: string;
  // Effects
  shadow: string;
  glow: string;
  glowSuccess: string;
  overlay: string;
  // Aurora background blobs
  auroraA: string;
  auroraB: string;
  auroraC: string;
  // Gradients
  gradientBrand: Gradient;
  gradientConnect: Gradient;
  gradientSuccess: Gradient;
  gradientSurface: Gradient;
  gradientHero: Gradient;
};

const light: Palette = {
  primary: '#0A84FF',
  primaryDark: '#0060DF',
  accent: '#7C4DFF',
  onPrimary: '#FFFFFF',
  background: '#EEF3FC',
  backgroundAlt: '#DCE7FA',
  card: 'rgba(255,255,255,0.86)',
  cardSolid: '#FFFFFF',
  cardAlt: 'rgba(10,132,255,0.10)',
  border: 'rgba(10,40,90,0.10)',
  borderStrong: 'rgba(10,40,90,0.18)',
  text: '#0B1220',
  muted: '#46536B',
  faint: '#6B7A93',
  danger: '#E23D3D',
  success: '#12B76A',
  warning: '#E8A33D',
  shadow: '#0B1220',
  glow: 'rgba(10,132,255,0.45)',
  glowSuccess: 'rgba(18,183,106,0.45)',
  overlay: 'rgba(8,14,28,0.45)',
  auroraA: 'rgba(10,132,255,0.30)',
  auroraB: 'rgba(124,77,255,0.26)',
  auroraC: 'rgba(0,214,214,0.22)',
  gradientBrand: ['#0A84FF', '#7C4DFF'],
  gradientConnect: ['#00D6D6', '#0A84FF', '#7C4DFF'],
  gradientSuccess: ['#12B76A', '#00D6D6'],
  gradientSurface: ['rgba(255,255,255,0.95)', 'rgba(255,255,255,0.72)'],
  gradientHero: ['rgba(10,132,255,0.16)', 'rgba(124,77,255,0.10)'],
};

const dark: Palette = {
  primary: '#4DA3FF',
  primaryDark: '#2E7FE0',
  accent: '#A78BFA',
  onPrimary: '#04101F',
  background: '#05070F',
  backgroundAlt: '#0B1020',
  card: 'rgba(22,29,48,0.72)',
  cardSolid: '#141B2E',
  cardAlt: 'rgba(77,163,255,0.14)',
  border: 'rgba(140,170,230,0.16)',
  borderStrong: 'rgba(140,170,230,0.28)',
  text: '#F2F6FF',
  muted: '#A3B1CC',
  faint: '#7E8DAB',
  danger: '#FF6B6B',
  success: '#3DD68C',
  warning: '#F0B45A',
  shadow: '#000000',
  glow: 'rgba(77,163,255,0.55)',
  glowSuccess: 'rgba(61,214,140,0.55)',
  overlay: 'rgba(2,4,10,0.65)',
  auroraA: 'rgba(10,132,255,0.34)',
  auroraB: 'rgba(124,77,255,0.30)',
  auroraC: 'rgba(0,214,214,0.20)',
  gradientBrand: ['#4DA3FF', '#A78BFA'],
  gradientConnect: ['#00E0E0', '#4DA3FF', '#A78BFA'],
  gradientSuccess: ['#3DD68C', '#00D6D6'],
  gradientSurface: ['rgba(30,40,66,0.92)', 'rgba(18,24,42,0.78)'],
  gradientHero: ['rgba(77,163,255,0.20)', 'rgba(167,139,250,0.14)'],
};

/** The active palette, following the theme chosen in the About tab. */
export function useColors(): Palette {
  const { theme } = useSettings();
  return theme === 'dark' ? dark : light;
}

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 44 };
export const radius = { sm: 10, md: 16, lg: 22, xl: 28, pill: 999 };

/** Reusable elevation presets so shadows look identical on every surface. */
export const elevation = {
  soft: {
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 4,
  },
  lifted: {
    shadowColor: '#000',
    shadowOpacity: 0.26,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 12 },
    elevation: 10,
  },
} as const;
